import { useState } from 'react';
import { Monitor, BookOpen, Target, Wrench, Phone, Mail, Menu, X, ChevronDown } from 'lucide-react';

function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur border-b border-slate-200 shadow-sm">
        <div className="max-w-5xl mx-auto px-6 flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Monitor className="text-blue-600" size={22} />
            <span className="font-bold text-slate-800 text-lg tracking-tight">Hardver Alapok</span>
          </div>
          <ul className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <li><button onClick={() => scrollTo('attekintes')} className="hover:text-blue-600 transition-colors">Áttekintés</button></li>
            <li><button onClick={() => scrollTo('celok')} className="hover:text-blue-600 transition-colors">Tanulási célok</button></li>
            <li><button onClick={() => scrollTo('eszkozok')} className="hover:text-blue-600 transition-colors">Eszközök</button></li>
            <li><button onClick={() => scrollTo('kapcsolat')} className="hover:text-blue-600 transition-colors">Kapcsolat</button></li>
          </ul>
          <button
            className="md:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Menü"
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
        {menuOpen && (
          <div className="md:hidden bg-white border-t border-slate-100 px-6 py-4 flex flex-col gap-4 text-sm font-medium text-slate-700">
            <button onClick={() => scrollTo('attekintes')} className="text-left hover:text-blue-600 transition-colors">Áttekintés</button>
            <button onClick={() => scrollTo('celok')} className="text-left hover:text-blue-600 transition-colors">Tanulási célok</button>
            <button onClick={() => scrollTo('eszkozok')} className="text-left hover:text-blue-600 transition-colors">Eszközök</button>
            <button onClick={() => scrollTo('kapcsolat')} className="text-left hover:text-blue-600 transition-colors">Kapcsolat</button>
          </div>
        )}
      </nav>

      {/* Hero */}
      <section className="min-h-screen flex flex-col items-center justify-center text-center px-6 pt-16 bg-gradient-to-br from-blue-600 via-blue-700 to-cyan-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-20 left-10 w-64 h-64 rounded-full bg-white blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 rounded-full bg-cyan-300 blur-3xl"></div>
        </div>
        <div className="relative z-10 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-white/15 border border-white/25 rounded-full px-4 py-1.5 text-white/90 text-sm font-medium mb-6">
            <Monitor size={15} />
            5. évfolyam — Informatika
          </div>
          <h1 className="text-5xl md:text-6xl font-extrabold text-white mb-5 leading-tight tracking-tight">
            Hardver Alapok
          </h1>
          <p className="text-xl md:text-2xl text-blue-100 font-medium mb-10 leading-relaxed">
            Rövid gyakorlás néhány kérdésen keresztül
          </p>
          <a
            href="https://canva.link/vd734gfd8jqgi7w"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-white text-blue-700 font-bold text-lg px-8 py-4 rounded-2xl shadow-xl hover:bg-blue-50 hover:scale-105 active:scale-95 transition-all duration-200"
          >
            <BookOpen size={22} />
            Indítsd el a tesztet!
          </a>
          <p className="mt-4 text-blue-200 text-sm">Kattints a gombra a feladatsor megnyitásához</p>
        </div>
        <button
          onClick={() => scrollTo('attekintes')}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/60 hover:text-white transition-colors animate-bounce"
          aria-label="Görgetés le"
        >
          <ChevronDown size={32} />
        </button>
      </section>

      {/* Tartalom áttekintés */}
      <section id="attekintes" className="py-20 px-6 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
              <BookOpen size={20} className="text-blue-600" />
            </div>
            <span className="text-sm font-semibold text-blue-600 uppercase tracking-widest">Tartalom áttekintés</span>
          </div>
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Mi vár rád?</h2>
          <p className="text-lg text-slate-600 leading-relaxed max-w-2xl">
            Tíz rövid feladat, a hardver elemek megjegyzésére.
          </p>
          <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { label: '10', desc: 'rövid feladat' },
              { label: '5.', desc: 'évfolyam' },
              { label: '~10', desc: 'perc alatt teljesíthető' },
            ].map(({ label, desc }) => (
              <div key={label} className="rounded-2xl bg-slate-50 border border-slate-100 p-6 text-center">
                <p className="text-4xl font-extrabold text-blue-600 mb-1">{label}</p>
                <p className="text-slate-500 text-sm font-medium">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tanulási célok */}
      <section id="celok" className="py-20 px-6 bg-slate-50">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
              <Target size={20} className="text-green-600" />
            </div>
            <span className="text-sm font-semibold text-green-600 uppercase tracking-widest">Tanulási célok</span>
          </div>
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Mit fogsz gyakorolni?</h2>
          <p className="text-lg text-slate-600 leading-relaxed max-w-2xl">
            Egy gyors felelevenítése néhány hardver elem feladatának.
          </p>
          <ul className="mt-8 space-y-4">
            {[
              'A számítógép legfontosabb hardver elemeinek azonosítása',
              'Az egyes komponensek szerepének felidézése',
              'Önálló tudás ellenőrzése rövid kérdések segítségével',
            ].map((item) => (
              <li key={item} className="flex items-start gap-3 bg-white rounded-xl px-5 py-4 border border-slate-100 shadow-sm">
                <span className="mt-1 w-5 h-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                  <span className="w-2 h-2 rounded-full bg-green-500 block"></span>
                </span>
                <span className="text-slate-700 text-sm font-medium">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Eszközök */}
      <section id="eszkozok" className="py-20 px-6 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
              <Wrench size={20} className="text-amber-600" />
            </div>
            <span className="text-sm font-semibold text-amber-600 uppercase tracking-widest">Eszközök</span>
          </div>
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Amire szükséged lesz</h2>
          <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { icon: '🌐', title: 'Webböngésző', desc: 'Bármely modern böngésző megfelel (Chrome, Firefox, Edge)' },
              { icon: '📶', title: 'Internetkapcsolat', desc: 'Stabil internet az online feladatsor eléréséhez' },
              { icon: '🔍', title: 'Kíváncsiság', desc: 'Egy rakás kíváncsiság — ez a legfontosabb!' },
            ].map(({ icon, title, desc }) => (
              <div key={title} className="rounded-2xl border border-slate-100 bg-slate-50 p-6 flex flex-col gap-3 hover:shadow-md transition-shadow">
                <span className="text-3xl">{icon}</span>
                <h3 className="font-bold text-slate-800">{title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 bg-gradient-to-r from-blue-600 to-cyan-600 text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-4">Készen állsz?</h2>
          <p className="text-blue-100 mb-8 text-lg">Kattints az alábbi gombra és kezdd el a feladatsort!</p>
          <a
            href="https://canva.link/vd734gfd8jqgi7w"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-white text-blue-700 font-bold text-lg px-8 py-4 rounded-2xl shadow-xl hover:bg-blue-50 hover:scale-105 active:scale-95 transition-all duration-200"
          >
            <BookOpen size={22} />
            Megyek a tesztre!
          </a>
        </div>
      </section>

      {/* Kapcsolat */}
      <section id="kapcsolat" className="py-20 px-6 bg-slate-800">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-2">Kapcsolat</h2>
          <p className="text-slate-400 mb-8 text-sm">Elérhetőségek</p>
          <div className="flex flex-col sm:flex-row gap-6">
            <a
              href="tel:06701234567"
              className="flex items-center gap-3 bg-slate-700 hover:bg-slate-600 transition-colors rounded-xl px-6 py-4 text-white font-medium"
            >
              <Phone size={18} className="text-blue-400" />
              06701234567
            </a>
            <a
              href="mailto:kitalaltemailcim@gmail.com"
              className="flex items-center gap-3 bg-slate-700 hover:bg-slate-600 transition-colors rounded-xl px-6 py-4 text-white font-medium"
            >
              <Mail size={18} className="text-cyan-400" />
              kitalaltemailcim@gmail.com
            </a>
          </div>
        </div>
      </section>

      <footer className="bg-slate-900 text-slate-500 text-center text-xs py-5 px-6">
        &copy; 2026 Hardver Alapok — 5. évfolyam informatika feladatsor
      </footer>
    </div>
  );
}

export default App;
