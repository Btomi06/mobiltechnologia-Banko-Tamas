export interface QuestionPair {
  aspect: string;
  smartphone: string;
  tablet: string;
}

export const questionPairs: QuestionPair[] = [
  {
    aspect: "Elsődleges cél",
    smartphone: "Azonnali kommunikáció és útközbeni tartalomfogyasztás.",
    tablet: "Mélyebb tartalomgyártás, tanulás és multimédiás élmény.",
  },
  {
    aspect: "Kijelzőméret",
    smartphone: "Kompakt (6-7\"), egy kézzel is kezelhető méret.",
    tablet: "Tágas (10-13\"), ami kétkezes használatot igényel.",
  },
  {
    aspect: "Hordozhatóság",
    smartphone: "Elfér a zsebben, mindig kéznél van.",
    tablet: "Táskát igényel, inkább stabilabb helyszíneken használják.",
  },
  {
    aspect: "Beviteli mód",
    smartphone: "Gyors gépelés hüvelykujjal, gesztusvezérlés.",
    tablet: "Stylus (toll) támogatás és külső billentyűzet-fókusz.",
  },
  {
    aspect: "Fotózás",
    smartphone: "Kiemelkedő kamerarendszer, optikai zoom, éjszakai mód.",
    tablet: "Alapszintű kamerák, inkább dokumentum-szkennelésre optimális.",
  },
  {
    aspect: "Akkumulátor",
    smartphone: "Egész napos üzemidő, de intenzív használat mellett tölteni kell.",
    tablet: "Hatalmas kapacitás, akár több napig bírja készenléti módban.",
  },
  {
    aspect: "Multitasking",
    smartphone: "Egyszerre főleg egy alkalmazás látszik a képernyőn.",
    tablet: "Osztott képernyős mód, több ablak futtatása egyszerre.",
  },
  {
    aspect: "Szoftver",
    smartphone: "Vertikális (függőleges) elrendezésre optimalizált appok.",
    tablet: "Desktop-szerű élmény, vízszintes nézetre és dokkolóra tervezve.",
  },
  {
    aspect: "Hívások",
    smartphone: "Beépített SIM-foglalat és közelségérzékelő telefonáláshoz.",
    tablet: "Gyakran csak Wi-Fi alapú, a hívás csak másodlagos funkció.",
  },
  {
    aspect: "Árazás",
    smartphone: "Széles skála, de a csúcsmobilok drágábbak a miniatürizálás miatt.",
    tablet: "Kedvezőbb ár-érték arány a nagy kijelzőhöz képest.",
  },
];
