import { useState, useEffect } from 'react';
import { Smartphone, Tablet, Moon, Sun, Trophy, RotateCcw } from 'lucide-react';
import { questionPairs, QuestionPair } from './data/quizData';

type DeviceType = 'smartphone' | 'tablet';

interface QuizQuestion {
  aspect: string;
  statement: string;
  correctAnswer: DeviceType;
}

function App() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [gameState, setGameState] = useState<'start' | 'playing' | 'finished'>('start');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<DeviceType | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const generateQuestions = (): QuizQuestion[] => {
    const shuffledPairs = [...questionPairs].sort(() => Math.random() - 0.5);
    return shuffledPairs.map((pair: QuestionPair) => {
      const useSmartphone = Math.random() > 0.5;
      return {
        aspect: pair.aspect,
        statement: useSmartphone ? pair.smartphone : pair.tablet,
        correctAnswer: useSmartphone ? 'smartphone' : 'tablet',
      };
    });
  };

  const startGame = () => {
    setQuestions(generateQuestions());
    setCurrentQuestionIndex(0);
    setScore(0);
    setGameState('playing');
    setSelectedAnswer(null);
    setShowFeedback(false);
  };

  const handleAnswer = (answer: DeviceType) => {
    if (showFeedback) return;

    const correct = answer === questions[currentQuestionIndex].correctAnswer;
    setSelectedAnswer(answer);
    setIsCorrect(correct);
    setShowFeedback(true);

    if (correct) {
      setScore((prev) => prev + 1);
    }

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex((prev) => prev + 1);
        setSelectedAnswer(null);
        setShowFeedback(false);
      } else {
        setGameState('finished');
      }
    }, 1500);
  };

  const getScoreMessage = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage === 100) return 'Tökéletes! Te egy igazi szakértő vagy!';
    if (percentage >= 70) return 'Nagyszerű! Jól ismered az eszközöket!';
    if (percentage >= 50) return 'Jó munka! Még van mit tanulni!';
    return 'Ne csüggedj, próbáld újra!';
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${
        isDarkMode
          ? 'bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900'
          : 'bg-gradient-to-br from-blue-50 via-white to-teal-50'
      }`}
    >
      {/* Dark Mode Toggle */}
      <button
        onClick={() => setIsDarkMode(!isDarkMode)}
        className={`fixed top-4 left-4 p-3 rounded-full transition-all duration-300 shadow-lg hover:scale-110 ${
          isDarkMode
            ? 'bg-slate-700 text-yellow-400 hover:bg-slate-600'
            : 'bg-white text-slate-700 hover:bg-gray-100'
        }`}
        aria-label="Toggle dark mode"
      >
        {isDarkMode ? <Sun size={24} /> : <Moon size={24} />}
      </button>

      {/* Start Screen */}
      {gameState === 'start' && (
        <div className="min-h-screen flex items-center justify-center p-4">
          <div
            className={`max-w-lg w-full p-8 rounded-3xl shadow-2xl text-center transition-all duration-300 ${
              isDarkMode ? 'bg-slate-800' : 'bg-white'
            }`}
          >
            <div className="flex justify-center gap-4 mb-6">
              <div
                className={`p-4 rounded-2xl ${
                  isDarkMode ? 'bg-blue-900/50' : 'bg-blue-100'
                }`}
              >
                <Smartphone
                  size={48}
                  className={isDarkMode ? 'text-blue-400' : 'text-blue-600'}
                />
              </div>
              <div
                className={`p-4 rounded-2xl ${
                  isDarkMode ? 'bg-teal-900/50' : 'bg-teal-100'
                }`}
              >
                <Tablet
                  size={48}
                  className={isDarkMode ? 'text-teal-400' : 'text-teal-600'}
                />
              </div>
            </div>
            <h1
              className={`text-3xl font-bold mb-4 ${
                isDarkMode ? 'text-white' : 'text-slate-800'
              }`}
            >
              Smartphone vs Tablet Quiz
            </h1>
            <p
              className={`text-lg mb-8 ${
                isDarkMode ? 'text-slate-300' : 'text-slate-600'
              }`}
            >
              Döntsd el, hogy az állítás egy okostelefonra vagy egy tabletre
              vonatkozik!
            </p>
            <button
              onClick={startGame}
              className="px-8 py-4 bg-gradient-to-r from-blue-500 to-teal-500 text-white text-xl font-semibold rounded-2xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
            >
              Játék indítása
            </button>
          </div>
        </div>
      )}

      {/* Playing Screen */}
      {gameState === 'playing' && questions.length > 0 && (
        <div className="min-h-screen flex items-center justify-center p-4">
          <div
            className={`max-w-2xl w-full p-8 rounded-3xl shadow-2xl transition-all duration-300 ${
              isDarkMode ? 'bg-slate-800' : 'bg-white'
            }`}
          >
            {/* Progress */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <span
                  className={`font-semibold ${
                    isDarkMode ? 'text-slate-300' : 'text-slate-600'
                  }`}
                >
                  Kérdés {currentQuestionIndex + 1} / {questions.length}
                </span>
                <span
                  className={`font-semibold ${
                    isDarkMode ? 'text-teal-400' : 'text-teal-600'
                  }`}
                >
                  Pontszám: {score}
                </span>
              </div>
              <div
                className={`h-3 rounded-full overflow-hidden ${
                  isDarkMode ? 'bg-slate-700' : 'bg-gray-200'
                }`}
              >
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-teal-500 transition-all duration-500"
                  style={{
                    width: `${((currentQuestionIndex + 1) / questions.length) * 100}%`,
                  }}
                />
              </div>
            </div>

            {/* Aspect Label */}
            <div
              className={`inline-block px-4 py-2 rounded-full text-sm font-semibold mb-4 ${
                isDarkMode
                  ? 'bg-blue-900/50 text-blue-300'
                  : 'bg-blue-100 text-blue-700'
              }`}
            >
              {questions[currentQuestionIndex].aspect}
            </div>

            {/* Question */}
            <div
              className={`text-2xl font-bold mb-8 leading-relaxed ${
                isDarkMode ? 'text-white' : 'text-slate-800'
              }`}
            >
              {questions[currentQuestionIndex].statement}
            </div>

            {/* Answer Buttons */}
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => handleAnswer('smartphone')}
                disabled={showFeedback}
                className={`p-6 rounded-2xl flex flex-col items-center gap-3 transition-all duration-300 ${
                  showFeedback
                    ? selectedAnswer === 'smartphone'
                      ? questions[currentQuestionIndex].correctAnswer ===
                        'smartphone'
                        ? 'bg-green-500 text-white scale-105 shadow-lg'
                        : 'bg-red-500 text-white scale-95'
                      : questions[currentQuestionIndex].correctAnswer ===
                        'smartphone'
                      ? 'bg-green-500/20 text-green-400'
                      : isDarkMode
                      ? 'bg-slate-700 text-slate-400'
                      : 'bg-gray-100 text-gray-400'
                    : isDarkMode
                    ? 'bg-slate-700 hover:bg-blue-900/50 text-white hover:scale-105'
                    : 'bg-gray-100 hover:bg-blue-100 text-slate-800 hover:scale-105'
                } ${!showFeedback ? 'shadow-lg hover:shadow-xl' : ''}`}
              >
                <Smartphone size={48} />
                <span className="text-lg font-semibold">Okostelefon</span>
              </button>

              <button
                onClick={() => handleAnswer('tablet')}
                disabled={showFeedback}
                className={`p-6 rounded-2xl flex flex-col items-center gap-3 transition-all duration-300 ${
                  showFeedback
                    ? selectedAnswer === 'tablet'
                      ? questions[currentQuestionIndex].correctAnswer === 'tablet'
                        ? 'bg-green-500 text-white scale-105 shadow-lg'
                        : 'bg-red-500 text-white scale-95'
                      : questions[currentQuestionIndex].correctAnswer === 'tablet'
                      ? 'bg-green-500/20 text-green-400'
                      : isDarkMode
                      ? 'bg-slate-700 text-slate-400'
                      : 'bg-gray-100 text-gray-400'
                    : isDarkMode
                    ? 'bg-slate-700 hover:bg-teal-900/50 text-white hover:scale-105'
                    : 'bg-gray-100 hover:bg-teal-100 text-slate-800 hover:scale-105'
                } ${!showFeedback ? 'shadow-lg hover:shadow-xl' : ''}`}
              >
                <Tablet size={48} />
                <span className="text-lg font-semibold">Tablet</span>
              </button>
            </div>

            {/* Feedback */}
            {showFeedback && (
              <div
                className={`mt-6 p-4 rounded-xl text-center font-semibold text-lg transition-all duration-300 ${
                  isCorrect
                    ? isDarkMode
                      ? 'bg-green-900/50 text-green-400'
                      : 'bg-green-100 text-green-700'
                    : isDarkMode
                    ? 'bg-red-900/50 text-red-400'
                    : 'bg-red-100 text-red-700'
                }`}
              >
                {isCorrect ? 'Helyes!' : 'Helytelen!'}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Finished Screen */}
      {gameState === 'finished' && (
        <div className="min-h-screen flex items-center justify-center p-4">
          <div
            className={`max-w-lg w-full p-8 rounded-3xl shadow-2xl text-center transition-all duration-300 ${
              isDarkMode ? 'bg-slate-800' : 'bg-white'
            }`}
          >
            <div
              className={`inline-block p-6 rounded-full mb-6 ${
                isDarkMode ? 'bg-yellow-900/50' : 'bg-yellow-100'
              }`}
            >
              <Trophy
                size={64}
                className={isDarkMode ? 'text-yellow-400' : 'text-yellow-600'}
              />
            </div>

            <h2
              className={`text-3xl font-bold mb-4 ${
                isDarkMode ? 'text-white' : 'text-slate-800'
              }`}
            >
              Játék vége!
            </h2>

            <div
              className={`text-6xl font-bold mb-4 ${
                isDarkMode ? 'text-teal-400' : 'text-teal-600'
              }`}
            >
              {score} / {questions.length}
            </div>

            <p
              className={`text-xl mb-8 ${
                isDarkMode ? 'text-slate-300' : 'text-slate-600'
              }`}
            >
              {getScoreMessage()}
            </p>

            <button
              onClick={startGame}
              className="px-8 py-4 bg-gradient-to-r from-blue-500 to-teal-500 text-white text-xl font-semibold rounded-2xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 flex items-center gap-3 mx-auto"
            >
              <RotateCcw size={24} />
              Újra játszom
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
