export interface Program {
  id: string;
  name: string;
  color: string;
}

export interface CardData {
  uniqueId: string;
  programId: string;
  isFlipped: boolean;
  isMatched: boolean;
}
