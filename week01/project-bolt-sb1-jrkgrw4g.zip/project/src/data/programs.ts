import { Program } from '../types';

export const PROGRAMS: Program[] = [
  { id: 'excel', name: 'Excel', color: '#1D6F42' },
  { id: 'word', name: 'Word', color: '#2B579A' },
  { id: 'paint', name: 'Paint', color: '#E74C3C' },
  { id: 'vscode', name: 'VS Code', color: '#0078D4' },
  { id: 'access', name: 'Access', color: '#A4373A' },
  { id: 'scratch', name: 'Scratch', color: '#FF6B35' },
  { id: 'chrome', name: 'Chrome', color: '#4285F4' },
  { id: 'explorer', name: 'Fájlkezelő', color: '#FFCA28' },
];
