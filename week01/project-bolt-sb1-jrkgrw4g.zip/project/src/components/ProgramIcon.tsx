interface IconProps {
  size?: number;
}

export function ExcelIcon({ size = 64 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="10" fill="#1D6F42" />
      <rect x="10" y="14" width="26" height="4" rx="1" fill="#A8D5B5" />
      <rect x="10" y="22" width="26" height="4" rx="1" fill="#A8D5B5" />
      <rect x="10" y="30" width="26" height="4" rx="1" fill="#A8D5B5" />
      <rect x="10" y="38" width="26" height="4" rx="1" fill="#A8D5B5" />
      <rect x="10" y="46" width="26" height="4" rx="1" fill="#A8D5B5" />
      <rect x="20" y="14" width="1.5" height="36" fill="#1D6F42" opacity="0.5" />
      <path d="M40 16 L56 48 L48 48 L44 38 L36 38 L32 48 L24 48 L40 16Z" fill="white" />
      <path d="M40 28 L43 38 L37 38 Z" fill="#1D6F42" />
    </svg>
  );
}

export function WordIcon({ size = 64 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="10" fill="#2B579A" />
      <path d="M10 16H36V48H10V16Z" fill="#1E4080" rx="2" />
      <path d="M10 16H40V22H10Z" fill="#2B579A" />
      <text x="32" y="44" textAnchor="middle" fill="white" fontSize="30" fontWeight="900" fontFamily="Arial, sans-serif">W</text>
    </svg>
  );
}

export function PaintIcon({ size = 64 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="10" fill="#F8F9FA" />
      <rect x="6" y="6" width="52" height="52" rx="8" fill="white" stroke="#E0E0E0" strokeWidth="1" />
      <circle cx="18" cy="18" r="6" fill="#E74C3C" />
      <circle cx="32" cy="18" r="6" fill="#F1C40F" />
      <circle cx="46" cy="18" r="6" fill="#2ECC71" />
      <circle cx="18" cy="32" r="6" fill="#3498DB" />
      <circle cx="32" cy="32" r="6" fill="#9B59B6" />
      <circle cx="46" cy="32" r="6" fill="#E67E22" />
      <path d="M24 46 C24 42 28 40 32 40 C36 40 40 42 40 46 C40 50 36 52 32 52 C28 52 24 50 24 46Z" fill="#1ABC9C" />
      <rect x="30" y="44" width="4" height="12" rx="2" fill="#7F8C8D" />
    </svg>
  );
}

export function VSCodeIcon({ size = 64 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="10" fill="#0078D4" />
      <path d="M44 10 L54 18 L54 46 L44 54 L10 36 L10 28 Z" fill="#1A9FFF" />
      <path d="M44 10 L10 28 L10 36 L44 54 Z" fill="#0078D4" />
      <path d="M44 10 L54 18 L44 26 Z" fill="white" opacity="0.3" />
      <path d="M10 28 L24 32 L10 36 Z" fill="white" opacity="0.2" />
      <path d="M44 54 L54 46 L44 38 Z" fill="white" opacity="0.3" />
      <text x="32" y="38" textAnchor="middle" fill="white" fontSize="16" fontWeight="bold" fontFamily="monospace">{'</>'}</text>
    </svg>
  );
}

export function AccessIcon({ size = 64 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="10" fill="#A4373A" />
      <ellipse cx="32" cy="20" rx="20" ry="7" fill="#C0494C" />
      <ellipse cx="32" cy="20" rx="20" ry="7" stroke="#E8787A" strokeWidth="1.5" fill="none" />
      <rect x="12" y="20" width="40" height="10" fill="#B04042" />
      <ellipse cx="32" cy="30" rx="20" ry="7" fill="#C0494C" />
      <ellipse cx="32" cy="30" rx="20" ry="7" stroke="#E8787A" strokeWidth="1.5" fill="none" />
      <rect x="12" y="30" width="40" height="10" fill="#B04042" />
      <ellipse cx="32" cy="40" rx="20" ry="7" fill="#C0494C" />
      <ellipse cx="32" cy="40" rx="20" ry="7" stroke="#E8787A" strokeWidth="1.5" fill="none" />
      <text x="32" y="44" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold" fontFamily="Arial">A</text>
    </svg>
  );
}

export function ScratchIcon({ size = 64 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="10" fill="#FF6B35" />
      <circle cx="32" cy="28" r="14" fill="#FFE066" />
      <circle cx="27" cy="24" r="2.5" fill="#333" />
      <circle cx="37" cy="24" r="2.5" fill="#333" />
      <circle cx="28" cy="23" r="1" fill="white" />
      <circle cx="38" cy="23" r="1" fill="white" />
      <path d="M26 32 Q32 38 38 32" stroke="#333" strokeWidth="2" fill="none" strokeLinecap="round" />
      <path d="M20 14 Q18 8 24 10" stroke="#FFE066" strokeWidth="3" strokeLinecap="round" fill="none" />
      <path d="M44 14 Q46 8 40 10" stroke="#FFE066" strokeWidth="3" strokeLinecap="round" fill="none" />
      <ellipse cx="32" cy="50" rx="12" ry="6" fill="#FF8C55" />
      <path d="M24 44 L20 54 L28 50 Z" fill="#FF8C55" />
      <path d="M40 44 L44 54 L36 50 Z" fill="#FF8C55" />
      <path d="M28 44 L26 56" stroke="#FF8C55" strokeWidth="3" strokeLinecap="round" />
      <path d="M36 44 L38 56" stroke="#FF8C55" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function ChromeIcon({ size = 64 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="10" fill="white" />
      <circle cx="32" cy="32" r="28" fill="white" />
      <path d="M32 4 L58 50 L6 50 Z" fill="#EA4335" />
      <path d="M6 50 L32 4 L32 28 Z" fill="#FBBC05" opacity="0.9" />
      <path d="M32 4 L58 50 L32 28 Z" fill="#34A853" opacity="0.9" />
      <path d="M6 50 L58 50 L32 60 Z" fill="#4285F4" opacity="0.9" />
      <circle cx="32" cy="32" r="14" fill="white" />
      <circle cx="32" cy="32" r="10" fill="#4285F4" />
      <circle cx="32" cy="32" r="6" fill="white" />
    </svg>
  );
}

export function ExplorerIcon({ size = 64 }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <rect width="64" height="64" rx="10" fill="#FFC107" />
      <rect x="8" y="20" width="48" height="36" rx="4" fill="#FFE082" />
      <rect x="8" y="20" width="48" height="36" rx="4" stroke="#F9A825" strokeWidth="1.5" fill="none" />
      <path d="M8 26 L56 26" stroke="#F9A825" strokeWidth="1" />
      <rect x="8" y="14" width="22" height="10" rx="3" fill="#FFCA28" />
      <rect x="8" y="14" width="22" height="10" rx="3" stroke="#F9A825" strokeWidth="1.5" fill="none" />
      <rect x="14" y="32" width="36" height="5" rx="2" fill="#F9A825" opacity="0.5" />
      <rect x="14" y="42" width="28" height="5" rx="2" fill="#F9A825" opacity="0.5" />
      <rect x="14" y="52" width="20" height="5" rx="2" fill="#F9A825" opacity="0.3" />
    </svg>
  );
}

export function getProgramIcon(id: string, size = 64) {
  switch (id) {
    case 'excel': return <ExcelIcon size={size} />;
    case 'word': return <WordIcon size={size} />;
    case 'paint': return <PaintIcon size={size} />;
    case 'vscode': return <VSCodeIcon size={size} />;
    case 'access': return <AccessIcon size={size} />;
    case 'scratch': return <ScratchIcon size={size} />;
    case 'chrome': return <ChromeIcon size={size} />;
    case 'explorer': return <ExplorerIcon size={size} />;
    default: return null;
  }
}
