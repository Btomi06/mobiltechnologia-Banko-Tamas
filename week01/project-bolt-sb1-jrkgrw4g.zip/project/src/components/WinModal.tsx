interface WinModalProps {
  moves: number;
  seconds: number;
  onRestart: () => void;
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function WinModal({ moves, seconds, onRestart }: WinModalProps) {
  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.6)',
        backdropFilter: 'blur(6px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 100,
        animation: 'fadeIn 0.3s ease',
      }}
    >
      <div
        style={{
          background: 'white',
          borderRadius: '24px',
          padding: '48px 56px',
          textAlign: 'center',
          boxShadow: '0 25px 80px rgba(0,0,0,0.4)',
          animation: 'slideUp 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)',
          maxWidth: '380px',
          width: '90%',
        }}
      >
        <div style={{ fontSize: '72px', marginBottom: '8px', lineHeight: 1 }}>
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none" style={{ margin: '0 auto' }}>
            <circle cx="40" cy="40" r="38" fill="#FFF9C4" stroke="#F9A825" strokeWidth="2" />
            <path d="M40 10 L44 30 L64 30 L48 44 L54 64 L40 52 L26 64 L32 44 L16 30 L36 30 Z" fill="#F9A825" />
          </svg>
        </div>
        <h2
          style={{
            fontSize: '28px',
            fontWeight: 800,
            color: '#1e293b',
            margin: '16px 0 8px',
            letterSpacing: '-0.5px',
          }}
        >
          Gratulalok!
        </h2>
        <p style={{ color: '#64748b', fontSize: '16px', marginBottom: '16px' }}>
          Megtalaltad az osszes part!
        </p>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '12px',
            margin: '20px 0 28px',
          }}
        >
          <div
            style={{
              background: 'linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%)',
              borderRadius: '12px',
              padding: '16px',
              border: '1px solid #7dd3fc',
            }}
          >
            <p style={{ color: '#0369a1', fontSize: '13px', marginBottom: '4px', fontWeight: 600 }}>Lepesek</p>
            <p
              style={{
                fontSize: '32px',
                fontWeight: 800,
                color: '#0c4a6e',
                lineHeight: 1,
              }}
            >
              {moves}
            </p>
          </div>
          <div
            style={{
              background: 'linear-gradient(135deg, #fce7f3 0%, #fbcfe8 100%)',
              borderRadius: '12px',
              padding: '16px',
              border: '1px solid #f472b6',
            }}
          >
            <p style={{ color: '#be185d', fontSize: '13px', marginBottom: '4px', fontWeight: 600 }}>Ido</p>
            <p
              style={{
                fontSize: '32px',
                fontWeight: 800,
                color: '#831843',
                lineHeight: 1,
              }}
            >
              {formatTime(seconds)}
            </p>
          </div>
        </div>
        <button
          onClick={onRestart}
          style={{
            background: 'linear-gradient(135deg, #2563eb, #1d4ed8)',
            color: 'white',
            border: 'none',
            borderRadius: '12px',
            padding: '14px 36px',
            fontSize: '16px',
            fontWeight: 700,
            cursor: 'pointer',
            width: '100%',
            boxShadow: '0 4px 15px rgba(37,99,235,0.4)',
            transition: 'all 0.2s ease',
            letterSpacing: '0.5px',
          }}
          onMouseEnter={e => {
            (e.target as HTMLButtonElement).style.transform = 'translateY(-2px)';
            (e.target as HTMLButtonElement).style.boxShadow = '0 8px 25px rgba(37,99,235,0.5)';
          }}
          onMouseLeave={e => {
            (e.target as HTMLButtonElement).style.transform = 'translateY(0)';
            (e.target as HTMLButtonElement).style.boxShadow = '0 4px 15px rgba(37,99,235,0.4)';
          }}
        >
          Uj jatek
        </button>
      </div>

      <style>{`
        @keyframes fadeIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(40px) scale(0.9) } to { opacity: 1; transform: translateY(0) scale(1) } }
      `}</style>
    </div>
  );
}
