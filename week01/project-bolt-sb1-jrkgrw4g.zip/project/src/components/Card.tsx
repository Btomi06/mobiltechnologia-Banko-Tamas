import { CardData } from '../types';
import { PROGRAMS } from '../data/programs';
import { getProgramIcon } from './ProgramIcon';

interface CardProps {
  card: CardData;
  onClick: (uniqueId: string) => void;
  disabled: boolean;
}

export function Card({ card, onClick, disabled }: CardProps) {
  const program = PROGRAMS.find(p => p.id === card.programId)!;
  const isVisible = card.isFlipped || card.isMatched;

  return (
    <div
      className="card-container"
      style={{ perspective: '1000px', width: '100%', aspectRatio: '1' }}
      onClick={() => !disabled && !isVisible && onClick(card.uniqueId)}
    >
      <div
        className="card-inner"
        style={{
          position: 'relative',
          width: '100%',
          height: '100%',
          transformStyle: 'preserve-3d',
          transition: 'transform 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
          transform: isVisible ? 'rotateY(180deg)' : 'rotateY(0deg)',
          cursor: (!disabled && !isVisible) ? 'pointer' : 'default',
        }}
      >
        <div
          className="card-back"
          style={{
            position: 'absolute',
            inset: 0,
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            borderRadius: '12px',
            overflow: 'hidden',
          }}
        >
          <div
            className="w-full h-full flex items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, #1e3a5f 0%, #2d5a8e 50%, #1e3a5f 100%)',
              borderRadius: '12px',
              border: '2px solid rgba(255,255,255,0.15)',
              boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
            }}
          >
            <div style={{ opacity: 0.5 }}>
              <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                <circle cx="20" cy="20" r="18" stroke="rgba(255,255,255,0.6)" strokeWidth="2" />
                <path d="M12 20 L20 12 L28 20 L20 28 Z" stroke="rgba(255,255,255,0.6)" strokeWidth="2" fill="none" />
                <circle cx="20" cy="20" r="4" fill="rgba(255,255,255,0.6)" />
              </svg>
            </div>
            <div
              style={{
                position: 'absolute',
                inset: 0,
                background: 'repeating-linear-gradient(45deg, transparent, transparent 8px, rgba(255,255,255,0.03) 8px, rgba(255,255,255,0.03) 16px)',
                borderRadius: '12px',
              }}
            />
          </div>
        </div>

        <div
          className="card-front"
          style={{
            position: 'absolute',
            inset: 0,
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)',
            borderRadius: '12px',
            overflow: 'hidden',
          }}
        >
          <div
            className="w-full h-full flex flex-col items-center justify-center gap-2"
            style={{
              background: card.isMatched
                ? `linear-gradient(135deg, ${program.color}22, ${program.color}44)`
                : 'white',
              borderRadius: '12px',
              border: card.isMatched
                ? `2px solid ${program.color}`
                : '2px solid #e5e7eb',
              boxShadow: card.isMatched
                ? `0 4px 20px ${program.color}44`
                : '0 4px 15px rgba(0,0,0,0.1)',
              transition: 'all 0.3s ease',
            }}
          >
            <div
              style={{
                transform: card.isMatched ? 'scale(1.05)' : 'scale(1)',
                transition: 'transform 0.3s ease',
              }}
            >
              {getProgramIcon(card.programId, 56)}
            </div>
            <span
              style={{
                fontSize: '11px',
                fontWeight: 600,
                color: program.color,
                textAlign: 'center',
                letterSpacing: '0.5px',
              }}
            >
              {program.name}
            </span>
            {card.isMatched && (
              <div
                style={{
                  position: 'absolute',
                  top: '6px',
                  right: '6px',
                  width: '18px',
                  height: '18px',
                  borderRadius: '50%',
                  background: program.color,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                  <path d="M2 5 L4 7 L8 3" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
