import { useState, useEffect, useCallback } from 'react';
import { CardData } from '../types';
import { PROGRAMS } from '../data/programs';
import { Card } from './Card';

function createShuffledCards(): CardData[] {
  const cards: CardData[] = [];
  PROGRAMS.forEach(program => {
    cards.push({ uniqueId: `${program.id}-a`, programId: program.id, isFlipped: false, isMatched: false });
    cards.push({ uniqueId: `${program.id}-b`, programId: program.id, isFlipped: false, isMatched: false });
  });
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  return cards;
}

interface GameBoardProps {
  onMoveCount: (count: number) => void;
  onMatchCount: (count: number) => void;
  onWin: () => void;
  onTimeUpdate: (seconds: number) => void;
  gameKey: number;
}

export function GameBoard({ onMoveCount, onMatchCount, onWin, onTimeUpdate, gameKey }: GameBoardProps) {
  const [cards, setCards] = useState<CardData[]>([]);
  const [flippedIds, setFlippedIds] = useState<string[]>([]);
  const [isChecking, setIsChecking] = useState(false);
  const [matchCount, setMatchCount] = useState(0);
  const [moveCount, setMoveCount] = useState(0);
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    setCards(createShuffledCards());
    setFlippedIds([]);
    setIsChecking(false);
    setMatchCount(0);
    setMoveCount(0);
    setSeconds(0);
  }, [gameKey]);

  useEffect(() => {
    const interval = setInterval(() => {
      setSeconds(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    onTimeUpdate(seconds);
  }, [seconds, onTimeUpdate]);

  useEffect(() => {
    onMoveCount(moveCount);
  }, [moveCount, onMoveCount]);

  useEffect(() => {
    onMatchCount(matchCount);
    if (matchCount === PROGRAMS.length) {
      setTimeout(onWin, 600);
    }
  }, [matchCount, onMatchCount, onWin]);

  const handleCardClick = useCallback((uniqueId: string) => {
    if (isChecking || flippedIds.includes(uniqueId)) return;

    const newFlipped = [...flippedIds, uniqueId];
    setFlippedIds(newFlipped);

    setCards(prev =>
      prev.map(c => c.uniqueId === uniqueId ? { ...c, isFlipped: true } : c)
    );

    if (newFlipped.length === 2) {
      setIsChecking(true);
      setMoveCount(prev => prev + 1);

      const [firstId, secondId] = newFlipped;
      const allCards = cards.map(c => c.uniqueId === uniqueId ? { ...c, isFlipped: true } : c);
      const first = allCards.find(c => c.uniqueId === firstId)!;
      const second = allCards.find(c => c.uniqueId === secondId)!;

      if (first.programId === second.programId) {
        setTimeout(() => {
          setCards(prev =>
            prev.map(c =>
              c.uniqueId === firstId || c.uniqueId === secondId
                ? { ...c, isMatched: true, isFlipped: false }
                : c
            )
          );
          setFlippedIds([]);
          setIsChecking(false);
          setMatchCount(prev => prev + 1);
        }, 600);
      } else {
        setTimeout(() => {
          setCards(prev =>
            prev.map(c =>
              c.uniqueId === firstId || c.uniqueId === secondId
                ? { ...c, isFlipped: false }
                : c
            )
          );
          setFlippedIds([]);
          setIsChecking(false);
        }, 1000);
      }
    }
  }, [isChecking, flippedIds, cards]);

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: '12px',
        width: '100%',
        maxWidth: '560px',
        margin: '0 auto',
      }}
    >
      {cards.map(card => (
        <Card
          key={card.uniqueId}
          card={card}
          onClick={handleCardClick}
          disabled={isChecking}
        />
      ))}
    </div>
  );
}
