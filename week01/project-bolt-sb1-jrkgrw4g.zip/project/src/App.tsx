import { useState, useCallback } from 'react';
import { GameBoard } from './components/GameBoard';
import { WinModal } from './components/WinModal';
import { PROGRAMS } from './data/programs';

export default function App() {
  const [gameKey, setGameKey] = useState(0);
  const [moves, setMoves] = useState(0);
  const [matches, setMatches] = useState(0);
  const [hasWon, setHasWon] = useState(false);
  const [seconds, setSeconds] = useState(0);

  const handleRestart = useCallback(() => {
    setGameKey(k => k + 1);
    setMoves(0);
    setMatches(0);
    setHasWon(false);
    setSeconds(0);
  }, []);

  const handleWin = useCallback(() => {
    setHasWon(true);
  }, []);

  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'linear-gradient(160deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%)',
        fontFamily: "'Segoe UI', system-ui, -apple-system, sans-serif",
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '24px 16px 40px',
      }}
    >
      <header style={{ textAlign: 'center', marginBottom: '32px', width: '100%', maxWidth: '560px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', marginBottom: '6px' }}>
          <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
            <rect width="36" height="36" rx="8" fill="rgba(255,255,255,0.1)" />
            <rect x="6" y="6" width="10" height="10" rx="2" fill="#60a5fa" />
            <rect x="20" y="6" width="10" height="10" rx="2" fill="#34d399" />
            <rect x="6" y="20" width="10" height="10" rx="2" fill="#f472b6" />
            <rect x="20" y="20" width="10" height="10" rx="2" fill="#fbbf24" />
          </svg>
          <h1
            style={{
              fontSize: '28px',
              fontWeight: 800,
              color: 'white',
              letterSpacing: '-0.5px',
              margin: 0,
            }}
          >
            Memoria Jatok
          </h1>
        </div>
        <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '14px', margin: '0 0 24px' }}>
          Informatikai programok memoriakartya jateka
        </p>

        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
          <StatCard label="Lepesek" value={moves} color="#60a5fa" />
          <StatCard label="Parok" value={`${matches}/${PROGRAMS.length}`} color="#34d399" />
          <StatCard label="Ido" value={formatTime(seconds)} color="#f472b6" />
          <button
            onClick={handleRestart}
            style={{
              background: 'rgba(255,255,255,0.08)',
              border: '1px solid rgba(255,255,255,0.15)',
              borderRadius: '12px',
              color: 'white',
              padding: '10px 20px',
              fontSize: '13px',
              fontWeight: 600,
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.15)';
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)';
            }}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M1 7C1 3.69 3.69 1 7 1C9.03 1 10.82 2.05 11.9 3.6L12.5 5H10" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M13 7C13 10.31 10.31 13 7 13C4.97 13 3.18 11.95 2.1 10.4L1.5 9H4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Uj jatek
          </button>
        </div>
      </header>

      <main style={{ width: '100%' }}>
        <GameBoard
          gameKey={gameKey}
          onMoveCount={setMoves}
          onMatchCount={setMatches}
          onWin={handleWin}
          onTimeUpdate={setSeconds}
        />
      </main>

      <footer style={{ marginTop: '32px', color: 'rgba(255,255,255,0.25)', fontSize: '12px', textAlign: 'center' }}>
        Talalj meg mind a 8 part!
      </footer>

      {hasWon && <WinModal moves={moves} seconds={seconds} onRestart={handleRestart} />}
    </div>
  );
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function StatCard({ label, value, color }: { label: string; value: string | number; color: string }) {
  return (
    <div
      style={{
        background: 'rgba(255,255,255,0.08)',
        border: '1px solid rgba(255,255,255,0.12)',
        borderRadius: '12px',
        padding: '10px 20px',
        minWidth: '90px',
        textAlign: 'center',
      }}
    >
      <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', fontWeight: 500, letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: '2px' }}>
        {label}
      </div>
      <div style={{ fontSize: '22px', fontWeight: 800, color }}>
        {value}
      </div>
    </div>
  );
}
