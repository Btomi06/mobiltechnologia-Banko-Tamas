/*
  # Create scores table for Digital Culture Quiz App

  1. New Tables
    - `scores`
      - `id` (uuid, primary key)
      - `correct_answers` (integer) - number of correct answers in a round
      - `total_questions` (integer) - total questions asked (always 8)
      - `time_taken` (integer) - seconds taken to complete the round
      - `created_at` (timestamptz) - when the score was recorded

  2. Security
    - Enable RLS on `scores` table
    - Public insert policy (no auth required for this educational app)
    - Public select policy (scores are viewable by anyone using the app)

  Note: This is a classroom tool with no user accounts, so scores are stored
  anonymously and publicly accessible within the app context.
*/

CREATE TABLE IF NOT EXISTS scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  correct_answers integer NOT NULL DEFAULT 0,
  total_questions integer NOT NULL DEFAULT 8,
  time_taken integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE scores ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert scores"
  ON scores
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anyone can view scores"
  ON scores
  FOR SELECT
  TO anon
  USING (true);
