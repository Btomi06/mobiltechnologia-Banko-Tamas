import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Score {
  id: string;
  correct_answers: number;
  total_questions: number;
  time_taken: number;
  created_at: string;
}

export async function saveScore(correctAnswers: number, timeTaken: number): Promise<void> {
  await supabase.from('scores').insert({
    correct_answers: correctAnswers,
    total_questions: 8,
    time_taken: timeTaken,
  });
}

export async function getScores(): Promise<Score[]> {
  const { data, error } = await supabase
    .from('scores')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(20);

  if (error) return [];
  return data ?? [];
}
