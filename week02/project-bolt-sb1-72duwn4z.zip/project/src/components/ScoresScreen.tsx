import { useEffect, useState } from 'react';
import { Trophy, Clock, ArrowLeft, Calendar } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { getScores, Score } from '../lib/supabase';

interface ScoresScreenProps {
  onBack: () => void;
}

export function ScoresScreen({ onBack }: ScoresScreenProps) {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  const [scores, setScores] = useState<Score[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getScores().then(data => {
      setScores(data);
      setLoading(false);
    });
  }, []);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('hu-HU', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getScoreColor = (correct: number, total: number) => {
    const pct = (correct / total) * 100;
    if (pct >= 90) return isDark ? 'text-emerald-400' : 'text-emerald-600';
    if (pct >= 75) return isDark ? 'text-blue-400' : 'text-blue-600';
    if (pct >= 50) return isDark ? 'text-amber-400' : 'text-amber-600';
    return isDark ? 'text-red-400' : 'text-red-600';
  };

  const getBadgeStyle = (correct: number, total: number) => {
    const pct = (correct / total) * 100;
    if (pct >= 90) return isDark ? 'bg-emerald-900/40 border-emerald-700 text-emerald-300' : 'bg-emerald-50 border-emerald-200 text-emerald-700';
    if (pct >= 75) return isDark ? 'bg-blue-900/40 border-blue-700 text-blue-300' : 'bg-blue-50 border-blue-200 text-blue-700';
    if (pct >= 50) return isDark ? 'bg-amber-900/40 border-amber-700 text-amber-300' : 'bg-amber-50 border-amber-200 text-amber-700';
    return isDark ? 'bg-red-900/40 border-red-700 text-red-300' : 'bg-red-50 border-red-200 text-red-700';
  };

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-300 ${isDark ? 'bg-gray-900' : 'bg-slate-50'}`}>
      <div className={`flex items-center gap-4 px-6 py-5 border-b ${isDark ? 'border-gray-800 bg-gray-900' : 'border-gray-200 bg-white shadow-sm'}`}>
        <button
          onClick={onBack}
          className={`p-2 rounded-xl transition-colors ${isDark ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100 text-gray-600'}`}
        >
          <ArrowLeft size={22} />
        </button>
        <div>
          <h1 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Korábbi eredmények
          </h1>
          <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            Az utolsó 20 játékos eredménye
          </p>
        </div>
      </div>

      <div className="flex-1 px-6 py-6 max-w-2xl mx-auto w-full">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-64 gap-4">
            <div className={`w-10 h-10 rounded-full border-4 border-t-transparent animate-spin ${isDark ? 'border-blue-500' : 'border-blue-400'}`} />
            <p className={isDark ? 'text-gray-400' : 'text-gray-500'}>Betöltés...</p>
          </div>
        ) : scores.length === 0 ? (
          <div className={`flex flex-col items-center justify-center h-64 gap-3 rounded-3xl border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}`}>
            <Trophy size={40} className={isDark ? 'text-gray-600' : 'text-gray-300'} />
            <p className={`font-semibold ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Még nincs eredmény</p>
            <p className={`text-sm ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>Indíts el egy játékot!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {scores.map((score, index) => (
              <div
                key={score.id}
                className={`flex items-center gap-4 px-5 py-4 rounded-2xl border transition-colors ${
                  isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200 shadow-sm'
                }`}
              >
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm flex-shrink-0 ${
                  index === 0
                    ? isDark ? 'bg-amber-500/20 text-amber-400' : 'bg-amber-100 text-amber-700'
                    : isDark ? 'bg-gray-700 text-gray-400' : 'bg-gray-100 text-gray-500'
                }`}>
                  {index + 1}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`font-bold text-lg ${getScoreColor(score.correct_answers, score.total_questions)}`}>
                      {score.correct_answers}/{score.total_questions}
                    </span>
                    <span className={`text-xs px-2 py-0.5 rounded-lg border font-medium ${getBadgeStyle(score.correct_answers, score.total_questions)}`}>
                      {Math.round((score.correct_answers / score.total_questions) * 100)}%
                    </span>
                  </div>
                  <div className={`flex items-center gap-3 mt-1 text-xs ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                    <span className="flex items-center gap-1">
                      <Clock size={12} />
                      {formatTime(score.time_taken)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar size={12} />
                      {formatDate(score.created_at)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
