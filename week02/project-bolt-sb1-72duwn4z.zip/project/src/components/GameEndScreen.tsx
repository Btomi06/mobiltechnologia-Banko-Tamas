import { Trophy, Clock, Home, Star } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface GameEndScreenProps {
  correct: number;
  total: number;
  timeTaken: number;
  onReset: () => void;
}

export function GameEndScreen({ correct, total, timeTaken, onReset }: GameEndScreenProps) {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const percentage = Math.round((correct / total) * 100);
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const getGradeInfo = () => {
    if (percentage >= 90) return { label: 'Kiváló!', color: isDark ? 'text-emerald-400' : 'text-emerald-600', bg: isDark ? 'bg-emerald-900/30 border-emerald-700' : 'bg-emerald-50 border-emerald-200' };
    if (percentage >= 75) return { label: 'Jó!', color: isDark ? 'text-blue-400' : 'text-blue-600', bg: isDark ? 'bg-blue-900/30 border-blue-700' : 'bg-blue-50 border-blue-200' };
    if (percentage >= 50) return { label: 'Közepes', color: isDark ? 'text-amber-400' : 'text-amber-600', bg: isDark ? 'bg-amber-900/30 border-amber-700' : 'bg-amber-50 border-amber-200' };
    return { label: 'Gyakorolj még!', color: isDark ? 'text-red-400' : 'text-red-600', bg: isDark ? 'bg-red-900/30 border-red-700' : 'bg-red-50 border-red-200' };
  };

  const grade = getGradeInfo();

  const circumference = 2 * Math.PI * 54;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center px-6 transition-colors duration-300 ${isDark ? 'bg-gray-900' : 'bg-slate-50'}`}>
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 ${isDark ? 'bg-amber-500/20' : 'bg-amber-100'}`}>
            <Trophy size={32} className={isDark ? 'text-amber-400' : 'text-amber-600'} />
          </div>
          <h1 className={`text-3xl font-bold mb-1 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Játék vége!
          </h1>
          <p className={`${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            Lássuk az eredményedet
          </p>
        </div>

        <div className={`rounded-3xl p-8 mb-6 text-center border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200 shadow-sm'}`}>
          <div className="flex justify-center mb-6">
            <div className="relative w-36 h-36">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
                <circle
                  cx="60" cy="60" r="54"
                  fill="none"
                  strokeWidth="8"
                  className={isDark ? 'stroke-gray-700' : 'stroke-gray-200'}
                />
                <circle
                  cx="60" cy="60" r="54"
                  fill="none"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  className={
                    percentage >= 75 ? 'stroke-emerald-500' :
                    percentage >= 50 ? 'stroke-amber-500' : 'stroke-red-500'
                  }
                  style={{ transition: 'stroke-dashoffset 1s ease' }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={`text-4xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  {correct}
                </span>
                <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                  / {total}
                </span>
              </div>
            </div>
          </div>

          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl border mb-4 ${grade.bg}`}>
            <Star size={16} className={grade.color} />
            <span className={`font-bold text-lg ${grade.color}`}>{grade.label}</span>
          </div>

          <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            {percentage}% helyes válasz
          </p>
        </div>

        <div className={`grid grid-cols-2 gap-4 mb-6`}>
          <div className={`rounded-2xl p-5 text-center border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200 shadow-sm'}`}>
            <div className={`flex justify-center mb-2`}>
              <Clock size={20} className={isDark ? 'text-blue-400' : 'text-blue-500'} />
            </div>
            <div className={`text-2xl font-bold font-mono ${isDark ? 'text-white' : 'text-gray-900'}`}>
              {formatTime(timeTaken)}
            </div>
            <div className={`text-xs mt-1 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Eltelt idő</div>
          </div>

          <div className={`rounded-2xl p-5 text-center border ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200 shadow-sm'}`}>
            <div className="flex justify-center mb-2">
              <Trophy size={20} className={isDark ? 'text-amber-400' : 'text-amber-500'} />
            </div>
            <div className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
              {correct}/{total}
            </div>
            <div className={`text-xs mt-1 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Pontszám</div>
          </div>
        </div>

        <button
          onClick={onReset}
          className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-2xl font-semibold text-lg bg-blue-500 hover:bg-blue-600 text-white transition-all duration-200 shadow-sm hover:shadow-md hover:-translate-y-0.5"
        >
          <Home size={20} />
          Vissza a főmenübe
        </button>
      </div>
    </div>
  );
}
