import { Play, Trophy, Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface MainMenuProps {
  onStartGame: () => void;
  onViewScores: () => void;
}

export function MainMenu({ onStartGame, onViewScores }: MainMenuProps) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center transition-colors duration-300 ${isDark ? 'bg-gray-900' : 'bg-slate-50'}`}>
      <div className="w-full max-w-md px-6">
        <div className="text-center mb-12">
          <div className={`inline-flex items-center justify-center w-20 h-20 rounded-2xl mb-6 ${isDark ? 'bg-blue-600' : 'bg-blue-500'} shadow-lg`}>
            <Play size={40} className="text-white ml-1" />
          </div>
          <h1 className={`text-4xl font-bold tracking-tight mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>
            Digitális Kultúra
          </h1>
          <p className={`text-lg ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            Fogalom kitalálós kvíz
          </p>
        </div>

        <div className="space-y-4">
          <button
            onClick={onStartGame}
            className={`w-full flex items-center gap-4 px-6 py-5 rounded-2xl text-left transition-all duration-200 shadow-sm hover:shadow-md hover:-translate-y-0.5 ${
              isDark
                ? 'bg-blue-600 hover:bg-blue-500 text-white'
                : 'bg-blue-500 hover:bg-blue-600 text-white'
            }`}
          >
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Play size={20} className="text-white ml-0.5" />
            </div>
            <div>
              <div className="font-semibold text-lg">Játék indítása</div>
              <div className="text-sm text-white/70">8 véletlenszerű fogalom</div>
            </div>
          </button>

          <button
            onClick={onViewScores}
            className={`w-full flex items-center gap-4 px-6 py-5 rounded-2xl text-left transition-all duration-200 shadow-sm hover:shadow-md hover:-translate-y-0.5 ${
              isDark
                ? 'bg-gray-800 hover:bg-gray-700 text-white border border-gray-700'
                : 'bg-white hover:bg-gray-50 text-gray-800 border border-gray-200'
            }`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${isDark ? 'bg-amber-500/20' : 'bg-amber-100'}`}>
              <Trophy size={20} className={isDark ? 'text-amber-400' : 'text-amber-600'} />
            </div>
            <div>
              <div className="font-semibold text-lg">Korábbi eredmények</div>
              <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Előző körök pontszámai</div>
            </div>
          </button>

          <button
            onClick={toggleTheme}
            className={`w-full flex items-center gap-4 px-6 py-5 rounded-2xl text-left transition-all duration-200 shadow-sm hover:shadow-md hover:-translate-y-0.5 ${
              isDark
                ? 'bg-gray-800 hover:bg-gray-700 text-white border border-gray-700'
                : 'bg-white hover:bg-gray-50 text-gray-800 border border-gray-200'
            }`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${isDark ? 'bg-slate-600/40' : 'bg-slate-100'}`}>
              {isDark ? (
                <Sun size={20} className="text-yellow-400" />
              ) : (
                <Moon size={20} className="text-slate-600" />
              )}
            </div>
            <div>
              <div className="font-semibold text-lg">
                {isDark ? 'Világos mód' : 'Sötét mód'}
              </div>
              <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                Jelenlegi: {isDark ? 'Sötét' : 'Világos'}
              </div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
