import { useState, useEffect, useRef } from 'react';
import { Clock, CheckCircle, XCircle, ChevronRight } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { Concept } from '../data/concepts';

interface GameScreenProps {
  questions: Concept[];
  onGameEnd: (correct: number, timeTaken: number) => void;
}

type AnswerState = 'idle' | 'correct' | 'wrong';

export function GameScreen({ questions, onGameEnd }: GameScreenProps) {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const [currentIndex, setCurrentIndex] = useState(0);
  const [input, setInput] = useState('');
  const [answerState, setAnswerState] = useState<AnswerState>('idle');
  const [correctCount, setCorrectCount] = useState(0);
  const [elapsed, setElapsed] = useState(0);

  const inputRef = useRef<HTMLInputElement>(null);
  const correctRef = useRef(0);
  const elapsedRef = useRef(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsed(prev => {
        elapsedRef.current = prev + 1;
        return prev + 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (answerState === 'idle') {
      inputRef.current?.focus();
    }
  }, [answerState, currentIndex]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const handleSubmit = () => {
    if (answerState !== 'idle') {
      const nextIndex = currentIndex + 1;
      if (nextIndex >= questions.length) {
        onGameEnd(correctRef.current, elapsedRef.current);
      } else {
        setCurrentIndex(nextIndex);
        setInput('');
        setAnswerState('idle');
      }
      return;
    }

    if (!input.trim()) return;

    const isCorrect = input.trim().toLowerCase() === questions[currentIndex].answer.toLowerCase();

    if (isCorrect) {
      correctRef.current += 1;
      setCorrectCount(correctRef.current);
      setAnswerState('correct');
    } else {
      setAnswerState('wrong');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSubmit();
  };

  const current = questions[currentIndex];
  const progress = (currentIndex / questions.length) * 100;

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-300 ${isDark ? 'bg-gray-900' : 'bg-slate-50'}`}>
      <div className={`w-full h-1.5 ${isDark ? 'bg-gray-800' : 'bg-gray-200'}`}>
        <div
          className="h-full bg-blue-500 transition-all duration-500"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className={`flex items-center justify-between px-6 py-4 border-b ${isDark ? 'border-gray-800' : 'border-gray-200'}`}>
        <div className={`text-sm font-semibold ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
          {currentIndex + 1} / {questions.length}
        </div>

        <div className={`flex items-center gap-2 px-4 py-2 rounded-xl font-mono text-lg font-bold ${
          isDark ? 'bg-gray-800 text-blue-400' : 'bg-white text-blue-600 shadow-sm border border-gray-200'
        }`}>
          <Clock size={18} />
          {formatTime(elapsed)}
        </div>

        <div className={`flex items-center gap-1.5 text-sm font-semibold ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>
          <CheckCircle size={16} />
          {correctCount} helyes
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-6 py-8">
        <div className="w-full max-w-2xl">
          <div className={`rounded-3xl p-8 mb-8 transition-colors duration-300 ${
            isDark ? 'bg-gray-800 border border-gray-700' : 'bg-white border border-gray-200 shadow-sm'
          }`}>
            <p className={`text-xs font-bold uppercase tracking-widest mb-4 ${isDark ? 'text-blue-400' : 'text-blue-500'}`}>
              Mi ennek a fogalomnak a neve?
            </p>
            <p className={`text-xl leading-relaxed font-medium ${isDark ? 'text-white' : 'text-gray-800'}`}>
              {current.question}
            </p>
          </div>

          {answerState !== 'idle' && (
            <div className={`rounded-2xl p-5 mb-6 flex items-start gap-3 ${
              answerState === 'correct'
                ? isDark ? 'bg-emerald-900/40 border border-emerald-700' : 'bg-emerald-50 border border-emerald-200'
                : isDark ? 'bg-red-900/40 border border-red-700' : 'bg-red-50 border border-red-200'
            }`}>
              {answerState === 'correct' ? (
                <CheckCircle size={22} className={`mt-0.5 flex-shrink-0 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`} />
              ) : (
                <XCircle size={22} className={`mt-0.5 flex-shrink-0 ${isDark ? 'text-red-400' : 'text-red-600'}`} />
              )}
              <div>
                <div className={`font-semibold ${
                  answerState === 'correct'
                    ? isDark ? 'text-emerald-300' : 'text-emerald-700'
                    : isDark ? 'text-red-300' : 'text-red-700'
                }`}>
                  {answerState === 'correct' ? 'Helyes!' : 'Helytelen!'}
                </div>
                {answerState === 'wrong' && (
                  <div className={`text-sm mt-1 ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                    A helyes válasz: <span className="font-semibold">{current.answer}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={answerState !== 'idle'}
              placeholder="Írd be a fogalmat..."
              className={`flex-1 px-5 py-4 rounded-2xl text-base outline-none transition-all duration-200 ${
                answerState === 'idle'
                  ? isDark
                    ? 'bg-gray-800 border border-gray-600 text-white placeholder-gray-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20'
                    : 'bg-white border border-gray-300 text-gray-800 placeholder-gray-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20 shadow-sm'
                  : isDark
                    ? 'bg-gray-800/60 border border-gray-700 text-gray-500 cursor-not-allowed'
                    : 'bg-gray-100 border border-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            />
            <button
              onClick={handleSubmit}
              className={`px-6 py-4 rounded-2xl font-semibold transition-all duration-200 flex items-center gap-2 whitespace-nowrap ${
                answerState === 'idle'
                  ? 'bg-blue-500 hover:bg-blue-600 text-white shadow-sm hover:shadow-md hover:-translate-y-0.5'
                  : isDark
                    ? 'bg-gray-700 hover:bg-gray-600 text-gray-200'
                    : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
              }`}
            >
              {answerState === 'idle' ? 'Ellenőriz' : (
                <>Tovább <ChevronRight size={18} /></>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
