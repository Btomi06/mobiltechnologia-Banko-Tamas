export interface Concept {
  question: string;
  answer: string;
}

export const concepts: Concept[] = [
  {
    question: 'Olyan táblázatkezelő művelet, amely több szomszédos rácselemet egyetlen közös tárolóegységgé olvaszt össze.',
    answer: 'cellaegyesítés',
  },
  {
    question: 'Az Excel fájltípus rövidítése.',
    answer: 'xlsx',
  },
  {
    question: 'Az Excel függvény, mely feltételeket alkalmaz több tartomány celláira, és megszámolja, hogy hány alkalommal teljesül valamennyi feltétel.',
    answer: 'darabhatöbb',
  },
  {
    question: 'Egy Excel függvény, mely egy adott elemet keres egy cellatartományban, majd visszaadja az elem relatív pozícióját a tartományban.',
    answer: 'hol.van',
  },
  {
    question: 'Olyan cellahivatkozási mód, amely a képlet másolásakor vagy mozgatásakor is változatlanul ugyanarra a meghatározott helyre mutat.',
    answer: 'abszolút hivatkozás',
  },
  {
    question: 'A forráskód formai helyességét meghatározó szabályok összessége.',
    answer: 'szintaxis',
  },
  {
    question: 'Egy olyan függvény, aminek nincs visszatérési értéke.',
    answer: 'eljárás',
  },
  {
    question: 'Programozásban olyan változó, melynek értéke állandó.',
    answer: 'konstans',
  },
  {
    question: 'Olyan összetett adattípus, amely ismétlésmentes elemeket tárol rendezetlenül.',
    answer: 'halmaz',
  },
  {
    question: 'Olyan ciklus, amely addig ismétlődik, amíg annak feltétele igaz.',
    answer: 'while',
  },
  {
    question: 'Adatbáziskezelő program, formátuma az .accdb.',
    answer: 'Access',
  },
  {
    question: 'Szövegszerkesztő program, legelterjedtebb formátuma a .docx.',
    answer: 'word',
  },
  {
    question: 'A Windows alapvető képszerkesztő programja, ikonja egy paletta.',
    answer: 'paint',
  },
  {
    question: 'Táblázatkezelő program, formátuma a .xlsx.',
    answer: 'Excel',
  },
  {
    question: 'Vektorgrafikus program, formátuma .svg.',
    answer: 'inkscape',
  },
];

export function getRandomQuestions(count: number = 8): Concept[] {
  const shuffled = [...concepts].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}
