import { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { MainMenu } from './components/MainMenu';
import { GameScreen } from './components/GameScreen';
import { GameEndScreen } from './components/GameEndScreen';
import { ScoresScreen } from './components/ScoresScreen';
import { getRandomQuestions, Concept } from './data/concepts';
import { saveScore } from './lib/supabase';

type Screen = 'menu' | 'game' | 'end' | 'scores';

interface GameResult {
  correct: number;
  timeTaken: number;
  total: number;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [questions, setQuestions] = useState<Concept[]>([]);
  const [result, setResult] = useState<GameResult | null>(null);

  const handleStartGame = () => {
    setQuestions(getRandomQuestions(8));
    setResult(null);
    setScreen('game');
  };

  const handleGameEnd = async (correct: number, timeTaken: number) => {
    const gameResult = { correct, timeTaken, total: 8 };
    setResult(gameResult);
    await saveScore(correct, timeTaken);
    setScreen('end');
  };

  const handleReset = () => {
    setScreen('menu');
    setResult(null);
    setQuestions([]);
  };

  return (
    <ThemeProvider>
      {screen === 'menu' && (
        <MainMenu
          onStartGame={handleStartGame}
          onViewScores={() => setScreen('scores')}
        />
      )}
      {screen === 'game' && (
        <GameScreen
          questions={questions}
          onGameEnd={handleGameEnd}
        />
      )}
      {screen === 'end' && result && (
        <GameEndScreen
          correct={result.correct}
          total={result.total}
          timeTaken={result.timeTaken}
          onReset={handleReset}
        />
      )}
      {screen === 'scores' && (
        <ScoresScreen onBack={() => setScreen('menu')} />
      )}
    </ThemeProvider>
  );
}
