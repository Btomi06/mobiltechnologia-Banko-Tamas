import { useState } from "react";
import { questions, Answer } from "./data/questions";
import ThemeToggle from "./components/ThemeToggle";
import WelcomeScreen from "./components/WelcomeScreen";
import QuestionCard from "./components/QuestionCard";
import ResultsScreen from "./components/ResultsScreen";

type Screen = "welcome" | "quiz" | "results";

export default function App() {
  const [dark, setDark] = useState(false);
  const [screen, setScreen] = useState<Screen>("welcome");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>(
    Array(questions.length).fill(null)
  );

  function handleStart() {
    setAnswers(Array(questions.length).fill(null));
    setCurrentIndex(0);
    setScreen("quiz");
  }

  function handleAnswer(answer: Answer) {
    const updated = [...answers];
    updated[currentIndex] = answer;
    setAnswers(updated);

    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((i) => i + 1);
    } else {
      setScreen("results");
    }
  }

  function handleRestart() {
    setAnswers(Array(questions.length).fill(null));
    setCurrentIndex(0);
    setScreen("welcome");
  }

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${
        dark
          ? "bg-slate-900"
          : "bg-gradient-to-br from-slate-50 via-cyan-50/30 to-blue-50/40"
      }`}
    >
      <ThemeToggle dark={dark} onToggle={() => setDark((d) => !d)} />

      {screen === "welcome" && (
        <WelcomeScreen dark={dark} onStart={handleStart} />
      )}

      {screen === "quiz" && (
        <QuestionCard
          dark={dark}
          question={questions[currentIndex]}
          current={currentIndex + 1}
          total={questions.length}
          onAnswer={handleAnswer}
        />
      )}

      {screen === "results" && (
        <ResultsScreen
          dark={dark}
          answers={answers}
          onRestart={handleRestart}
        />
      )}
    </div>
  );
}
