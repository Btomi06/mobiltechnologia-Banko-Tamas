export interface Question {
  id: number;
  category: string;
  icon: string;
  question: string;
}

export const questions: Question[] = [
  {
    id: 1,
    category: "Képernyőzár",
    icon: "lock",
    question:
      "Be van állítva a telefonodon legalább egy 6 jegyű PIN kód vagy biometrikus azonosítás (arc/ujjlenyomat)?",
  },
  {
    id: 2,
    category: "Kétfaktoros hitelesítés (2FA)",
    icon: "shield-check",
    question:
      "Van telepítve a telefonodon hitelesítő alkalmazás (pl. Google vagy Microsoft Authenticator)?",
  },
  {
    id: 3,
    category: "Fiókvédelem",
    icon: "user-check",
    question:
      "Be van kapcsolva a kétfaktoros hitelesítés legalább egy fontos közösségi média fiókodban (pl. Instagram, TikTok, Google)?",
  },
  {
    id: 4,
    category: "Alkalmazás-engedélyek",
    icon: "eye",
    question:
      "Ellenőrizted az elmúlt hónapban, hogy mely appok férnek hozzá a mikrofonodhoz vagy a kamerádhoz feleslegesen?",
  },
  {
    id: 5,
    category: "Készülékkeresés",
    icon: "map-pin",
    question:
      "Aktív a telefonodon a \"Készülékkereső\" (Find My / Find My Device) funkció, hogy elvesztés esetén távolról törölhesd?",
  },
  {
    id: 6,
    category: "Rendszerfrissítés",
    icon: "refresh-cw",
    question:
      "A legfrissebb elérhető biztonsági javítás és szoftververzió fut jelenleg az eszközödön?",
  },
  {
    id: 7,
    category: "Hálózati biztonság",
    icon: "wifi",
    question:
      "Megfogadod, hogy soha nem lépsz be érzékeny fiókba (pl. bank, e-mail) nyilvános WiFi-n, hacsak nem használsz VPN-t?",
  },
  {
    id: 8,
    category: "Adathalászat felismerése",
    icon: "fish",
    question:
      "Tudod-e, hogyan kell ellenőrizni egy gyanús e-mail feladóját, mielőtt rákattintanál egy linkre?",
  },
  {
    id: 9,
    category: "Felugró ablakok kezelése",
    icon: "alert-triangle",
    question:
      "Tudod-e, hogy a böngészőben megjelenő \"Vírust találtunk!\" üzeneteket csak a böngészőfül bezárásával szabad kezelni?",
  },
  {
    id: 10,
    category: "Adatminimalizálás (GDPR)",
    icon: "database",
    question:
      "Kerülöd a valódi neved és adataid megadását gyanús vagy felesleges online regisztrációk során?",
  },
  {
    id: 11,
    category: "Automatikus lezárás",
    icon: "clock",
    question:
      "Be van állítva a telefonodon, hogy maximum 1-2 perc tétlenség után magától lezárjon a képernyő?",
  },
];

export type Answer = "yes" | "no" | null;

export function getScoreMessage(score: number): {
  title: string;
  subtitle: string;
  level: "safe" | "warning" | "danger";
} {
  if (score >= 9) {
    return {
      title: "Nagyon biztonságos az eszközöd.",
      subtitle:
        "Kiváló munkát végeztél! Az eszközöd védelme a legmagasabb szinten van.",
      level: "safe",
    };
  } else if (score >= 6) {
    return {
      title: "Az eszközöd biztonsága veszélyben lehet.",
      subtitle:
        "Néhány fontos beállítást érdemes ellenőrizni és javítani a jobb védelem érdekében.",
      level: "warning",
    };
  } else {
    return {
      title: "Az eszközöd nincs biztonságban.",
      subtitle:
        "Sürgősen szükséges lépéseket tenni az eszközöd és adataid védelme érdekében.",
      level: "danger",
    };
  }
}
