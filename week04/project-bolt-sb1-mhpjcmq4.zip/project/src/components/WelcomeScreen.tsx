import { Shield } from "lucide-react";

interface WelcomeScreenProps {
  dark: boolean;
  onStart: () => void;
}

export default function WelcomeScreen({ dark, onStart }: WelcomeScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 py-16">
      <div
        className={`
        w-full max-w-md rounded-3xl p-8 shadow-2xl text-center
        transition-all duration-300
        ${dark ? "bg-slate-800 shadow-slate-900/60" : "bg-white shadow-gray-200/80"}
      `}
      >
        <div
          className={`
          mx-auto mb-6 w-24 h-24 rounded-2xl flex items-center justify-center
          ${dark ? "bg-cyan-500/20" : "bg-cyan-50"}
        `}
        >
          <Shield
            size={48}
            className={dark ? "text-cyan-400" : "text-cyan-600"}
          />
        </div>

        <h1
          className={`text-2xl font-bold mb-2 ${dark ? "text-white" : "text-slate-800"}`}
        >
          Digitális Biztonsági Teszt
        </h1>
        <p
          className={`text-sm font-medium mb-4 ${dark ? "text-cyan-400" : "text-cyan-600"}`}
        >
          9–10. évfolyam
        </p>

        <p
          className={`text-sm leading-relaxed mb-8 ${dark ? "text-slate-300" : "text-slate-600"}`}
        >
          Ez a teszt segít felmérni, mennyire biztonságos az okostelefonod és
          digitális fiókjaid. Válaszolj minden kérdésre őszintén – a végén
          megtudod, mennyire vagy védett!
        </p>

        <div
          className={`
          rounded-xl p-4 mb-8 text-left
          ${dark ? "bg-slate-700/60" : "bg-slate-50"}
        `}
        >
          <p
            className={`text-xs font-semibold uppercase tracking-wide mb-2 ${dark ? "text-slate-400" : "text-slate-500"}`}
          >
            Hogyan működik?
          </p>
          <ul
            className={`text-sm space-y-1.5 ${dark ? "text-slate-300" : "text-slate-600"}`}
          >
            <li className="flex items-start gap-2">
              <span className="mt-0.5 text-emerald-500">✓</span>
              <span>Ha igaz rád a kérdés, nyomj zöld pipát</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-0.5 text-red-500">✗</span>
              <span>Ha nem igaz, nyomj piros X-et</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="mt-0.5 text-cyan-500">★</span>
              <span>A végén pontszámot és értékelést kapsz</span>
            </li>
          </ul>
        </div>

        <button
          onClick={onStart}
          className="w-full py-3.5 rounded-xl font-semibold text-white text-base
            bg-gradient-to-r from-cyan-500 to-blue-600
            hover:from-cyan-400 hover:to-blue-500
            active:scale-95 transition-all duration-200 shadow-lg shadow-cyan-500/30"
        >
          Teszt indítása →
        </button>
      </div>
    </div>
  );
}
