import { Sun, Moon } from "lucide-react";

interface ThemeToggleProps {
  dark: boolean;
  onToggle: () => void;
}

export default function ThemeToggle({ dark, onToggle }: ThemeToggleProps) {
  return (
    <button
      onClick={onToggle}
      aria-label="Téma váltása"
      className={`
        fixed top-4 right-4 z-50 w-11 h-11 rounded-full flex items-center justify-center
        shadow-lg border transition-all duration-300
        ${
          dark
            ? "bg-slate-700 border-slate-600 text-amber-400 hover:bg-slate-600"
            : "bg-white border-gray-200 text-slate-700 hover:bg-gray-50"
        }
      `}
    >
      {dark ? <Sun size={20} /> : <Moon size={20} />}
    </button>
  );
}
