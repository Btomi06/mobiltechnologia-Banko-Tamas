import { useState, useEffect } from "react";
import {
  Lock,
  ShieldCheck,
  UserCheck,
  Eye,
  MapPin,
  RefreshCw,
  Wifi,
  Fish,
  AlertTriangle,
  Database,
  Clock,
  Check,
  X,
} from "lucide-react";
import { Question, Answer } from "../data/questions";

const iconMap: Record<string, React.ReactNode> = {
  lock: <Lock size={28} />,
  "shield-check": <ShieldCheck size={28} />,
  "user-check": <UserCheck size={28} />,
  eye: <Eye size={28} />,
  "map-pin": <MapPin size={28} />,
  "refresh-cw": <RefreshCw size={28} />,
  wifi: <Wifi size={28} />,
  fish: <Fish size={28} />,
  "alert-triangle": <AlertTriangle size={28} />,
  database: <Database size={28} />,
  clock: <Clock size={28} />,
};

interface QuestionCardProps {
  dark: boolean;
  question: Question;
  current: number;
  total: number;
  onAnswer: (answer: Answer) => void;
}

export default function QuestionCard({
  dark,
  question,
  current,
  total,
  onAnswer,
}: QuestionCardProps) {
  const [visible, setVisible] = useState(false);
  const [chosen, setChosen] = useState<Answer>(null);

  useEffect(() => {
    setChosen(null);
    setVisible(false);
    const t = setTimeout(() => setVisible(true), 30);
    return () => clearTimeout(t);
  }, [question.id]);

  function handleChoice(answer: Answer) {
    if (chosen) return;
    setChosen(answer);
    setTimeout(() => {
      onAnswer(answer);
    }, 500);
  }

  const progress = (current / total) * 100;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 py-16">
      <div
        className={`
        w-full max-w-md transition-all duration-500
        ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}
      `}
      >
        {/* Progress bar */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <span
              className={`text-xs font-semibold uppercase tracking-wide ${dark ? "text-slate-400" : "text-slate-500"}`}
            >
              {current}. kérdés / {total}
            </span>
            <span
              className={`text-xs font-bold ${dark ? "text-cyan-400" : "text-cyan-600"}`}
            >
              {Math.round(progress)}%
            </span>
          </div>
          <div
            className={`h-2 rounded-full overflow-hidden ${dark ? "bg-slate-700" : "bg-gray-200"}`}
          >
            <div
              className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 transition-all duration-700"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Card */}
        <div
          className={`
          rounded-3xl p-8 shadow-2xl
          ${dark ? "bg-slate-800 shadow-slate-900/60" : "bg-white shadow-gray-200/80"}
        `}
        >
          {/* Category badge + icon */}
          <div className="flex items-center gap-3 mb-6">
            <div
              className={`w-14 h-14 rounded-xl flex items-center justify-center shrink-0 ${dark ? "bg-cyan-500/20 text-cyan-400" : "bg-cyan-50 text-cyan-600"}`}
            >
              {iconMap[question.icon]}
            </div>
            <div>
              <p
                className={`text-xs font-semibold uppercase tracking-wide ${dark ? "text-slate-400" : "text-slate-500"}`}
              >
                Kategória
              </p>
              <p
                className={`text-sm font-bold ${dark ? "text-cyan-300" : "text-cyan-700"}`}
              >
                {question.category}
              </p>
            </div>
          </div>

          {/* Question text */}
          <p
            className={`text-base leading-relaxed mb-8 font-medium ${dark ? "text-slate-100" : "text-slate-800"}`}
          >
            {question.question}
          </p>

          {/* Answer buttons */}
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleChoice("yes")}
              className={`
                relative py-5 rounded-2xl font-bold text-base flex flex-col items-center gap-2
                transition-all duration-200 active:scale-95
                ${
                  chosen === "yes"
                    ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/40 scale-105"
                    : chosen === "no"
                      ? "opacity-30 cursor-default"
                      : dark
                        ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/25"
                        : "bg-emerald-50 text-emerald-600 border border-emerald-200 hover:bg-emerald-100"
                }
              `}
            >
              <Check
                size={32}
                strokeWidth={2.5}
                className={chosen === "yes" ? "text-white" : ""}
              />
              <span className="text-sm">Igen</span>
            </button>

            <button
              onClick={() => handleChoice("no")}
              className={`
                relative py-5 rounded-2xl font-bold text-base flex flex-col items-center gap-2
                transition-all duration-200 active:scale-95
                ${
                  chosen === "no"
                    ? "bg-red-500 text-white shadow-lg shadow-red-500/40 scale-105"
                    : chosen === "yes"
                      ? "opacity-30 cursor-default"
                      : dark
                        ? "bg-red-500/15 text-red-400 border border-red-500/40 hover:bg-red-500/25"
                        : "bg-red-50 text-red-600 border border-red-200 hover:bg-red-100"
                }
              `}
            >
              <X
                size={32}
                strokeWidth={2.5}
                className={chosen === "no" ? "text-white" : ""}
              />
              <span className="text-sm">Nem</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
