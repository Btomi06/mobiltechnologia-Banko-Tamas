import { Shield, ShieldAlert, ShieldX, Check, X, RotateCcw } from "lucide-react";
import { questions, Answer, getScoreMessage } from "../data/questions";

interface ResultsScreenProps {
  dark: boolean;
  answers: Answer[];
  onRestart: () => void;
}

export default function ResultsScreen({
  dark,
  answers,
  onRestart,
}: ResultsScreenProps) {
  const score = answers.filter((a) => a === "yes").length;
  const { title, subtitle, level } = getScoreMessage(score);

  const levelConfig = {
    safe: {
      icon: <Shield size={52} />,
      iconClass: dark ? "text-emerald-400" : "text-emerald-600",
      bgClass: dark ? "bg-emerald-500/20" : "bg-emerald-50",
      titleClass: dark ? "text-emerald-400" : "text-emerald-700",
      barClass: "bg-gradient-to-r from-emerald-400 to-teal-500",
      badge: "Biztonságos",
      badgeBg: dark ? "bg-emerald-500/20 text-emerald-400" : "bg-emerald-100 text-emerald-700",
    },
    warning: {
      icon: <ShieldAlert size={52} />,
      iconClass: dark ? "text-amber-400" : "text-amber-600",
      bgClass: dark ? "bg-amber-500/20" : "bg-amber-50",
      titleClass: dark ? "text-amber-400" : "text-amber-700",
      barClass: "bg-gradient-to-r from-amber-400 to-orange-500",
      badge: "Figyelmet igényel",
      badgeBg: dark ? "bg-amber-500/20 text-amber-400" : "bg-amber-100 text-amber-700",
    },
    danger: {
      icon: <ShieldX size={52} />,
      iconClass: dark ? "text-red-400" : "text-red-600",
      bgClass: dark ? "bg-red-500/20" : "bg-red-50",
      titleClass: dark ? "text-red-400" : "text-red-700",
      barClass: "bg-gradient-to-r from-red-400 to-rose-600",
      badge: "Veszélyes",
      badgeBg: dark ? "bg-red-500/20 text-red-400" : "bg-red-100 text-red-700",
    },
  };

  const cfg = levelConfig[level];
  const percentage = Math.round((score / questions.length) * 100);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-4 py-12">
      <div className="w-full max-w-md space-y-5">
        {/* Score card */}
        <div
          className={`
          rounded-3xl p-8 shadow-2xl text-center
          ${dark ? "bg-slate-800 shadow-slate-900/60" : "bg-white shadow-gray-200/80"}
        `}
        >
          <div
            className={`mx-auto mb-5 w-24 h-24 rounded-2xl flex items-center justify-center ${cfg.bgClass}`}
          >
            <span className={cfg.iconClass}>{cfg.icon}</span>
          </div>

          <div
            className={`inline-block px-3 py-1 rounded-full text-xs font-bold mb-4 ${cfg.badgeBg}`}
          >
            {cfg.badge}
          </div>

          <h2
            className={`text-xl font-bold mb-2 leading-snug ${cfg.titleClass}`}
          >
            {title}
          </h2>
          <p
            className={`text-sm leading-relaxed mb-6 ${dark ? "text-slate-300" : "text-slate-600"}`}
          >
            {subtitle}
          </p>

          {/* Score display */}
          <div className="mb-3">
            <div className="flex justify-between text-xs font-semibold mb-2">
              <span className={dark ? "text-slate-400" : "text-slate-500"}>
                Pontszám
              </span>
              <span className={dark ? "text-slate-200" : "text-slate-700"}>
                {score} / {questions.length}
              </span>
            </div>
            <div
              className={`h-3 rounded-full overflow-hidden ${dark ? "bg-slate-700" : "bg-gray-100"}`}
            >
              <div
                className={`h-full rounded-full transition-all duration-1000 ${cfg.barClass}`}
                style={{ width: `${percentage}%` }}
              />
            </div>
            <p
              className={`text-right text-xs mt-1 font-bold ${dark ? "text-slate-400" : "text-slate-500"}`}
            >
              {percentage}%
            </p>
          </div>
        </div>

        {/* Answer summary */}
        <div
          className={`
          rounded-3xl overflow-hidden shadow-xl
          ${dark ? "bg-slate-800 shadow-slate-900/60" : "bg-white shadow-gray-200/80"}
        `}
        >
          <div
            className={`px-6 py-4 border-b ${dark ? "border-slate-700" : "border-gray-100"}`}
          >
            <h3
              className={`font-bold text-sm uppercase tracking-wide ${dark ? "text-slate-300" : "text-slate-600"}`}
            >
              Válaszok összegzése
            </h3>
          </div>
          <div className="divide-y divide-opacity-50">
            {questions.map((q, idx) => {
              const answer = answers[idx];
              return (
                <div
                  key={q.id}
                  className={`
                    flex items-start gap-3 px-5 py-3.5
                    ${dark ? "divide-slate-700" : "divide-gray-100"}
                  `}
                >
                  <div
                    className={`
                    mt-0.5 shrink-0 w-6 h-6 rounded-full flex items-center justify-center
                    ${
                      answer === "yes"
                        ? "bg-emerald-500"
                        : "bg-red-500"
                    }
                  `}
                  >
                    {answer === "yes" ? (
                      <Check size={13} strokeWidth={3} className="text-white" />
                    ) : (
                      <X size={13} strokeWidth={3} className="text-white" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-xs font-bold mb-0.5 ${dark ? "text-cyan-400" : "text-cyan-600"}`}
                    >
                      {q.category}
                    </p>
                    <p
                      className={`text-xs leading-relaxed ${dark ? "text-slate-300" : "text-slate-600"}`}
                    >
                      {q.question}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Restart button */}
        <button
          onClick={onRestart}
          className={`
            w-full py-3.5 rounded-2xl font-semibold text-base flex items-center justify-center gap-2
            transition-all duration-200 active:scale-95
            ${
              dark
                ? "bg-slate-700 text-slate-200 hover:bg-slate-600 border border-slate-600"
                : "bg-white text-slate-700 hover:bg-slate-50 border border-slate-200 shadow"
            }
          `}
        >
          <RotateCcw size={18} />
          Újra kezdés
        </button>
      </div>
    </div>
  );
}
