/*
  # Create Quiz Attempts Table

  ## Summary
  Creates a table to store quiz attempt history for the computer hardware quiz app
  used by 5th grade students.

  ## New Tables
  - `quiz_attempts`
    - `id` (uuid, primary key) - unique attempt identifier
    - `created_at` (timestamptz) - when the attempt was made
    - `score` (integer) - number of correct answers
    - `total_questions` (integer) - total number of questions in the quiz
    - `percentage` (integer) - score as percentage (0–100)

  ## Security
  - RLS enabled on `quiz_attempts`
  - Public insert allowed (anonymous students can submit scores)
  - Public select allowed (students can view history on device)
  - No update or delete allowed to protect score integrity
*/

CREATE TABLE IF NOT EXISTS quiz_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  score integer NOT NULL DEFAULT 0,
  total_questions integer NOT NULL DEFAULT 0,
  percentage integer NOT NULL DEFAULT 0
);

ALTER TABLE quiz_attempts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert quiz attempts"
  ON quiz_attempts
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anyone can view quiz attempts"
  ON quiz_attempts
  FOR SELECT
  TO anon
  USING (true);
