import { useEffect, useState, useCallback } from 'react';
import { Question } from '../data/questions';

const ANSWER_LABELS = ['A', 'B', 'C', 'D'];

const ANSWER_STYLES = [
  { bg: 'bg-red-500 hover:bg-red-400 border-red-600', selected: 'ring-4 ring-red-300', label: 'bg-red-700' },
  { bg: 'bg-blue-500 hover:bg-blue-400 border-blue-600', selected: 'ring-4 ring-blue-300', label: 'bg-blue-700' },
  { bg: 'bg-amber-500 hover:bg-amber-400 border-amber-600', selected: 'ring-4 ring-amber-300', label: 'bg-amber-700' },
  { bg: 'bg-emerald-500 hover:bg-emerald-400 border-emerald-600', selected: 'ring-4 ring-emerald-300', label: 'bg-emerald-700' },
];

const TIME_LIMIT = 30;

interface Props {
  question: Question;
  questionIndex: number;
  totalQuestions: number;
  darkMode: boolean;
  onAnswer: (answerIndex: number | null) => void;
}

export default function QuizQuestion({ question, questionIndex, totalQuestions, darkMode, onAnswer }: Props) {
  const [timeLeft, setTimeLeft] = useState(TIME_LIMIT);
  const [selected, setSelected] = useState<number | null>(null);
  const [locked, setLocked] = useState(false);

  const submit = useCallback(
    (index: number | null) => {
      if (locked) return;
      setLocked(true);
      setSelected(index);
      setTimeout(() => onAnswer(index), 600);
    },
    [locked, onAnswer]
  );

  useEffect(() => {
    setTimeLeft(TIME_LIMIT);
    setSelected(null);
    setLocked(false);
  }, [question]);

  useEffect(() => {
    if (locked) return;
    if (timeLeft <= 0) {
      submit(null);
      return;
    }
    const id = setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(id);
  }, [timeLeft, locked, submit]);

  const timerPct = (timeLeft / TIME_LIMIT) * 100;
  const timerColor =
    timeLeft > 15 ? 'bg-emerald-500' : timeLeft > 8 ? 'bg-amber-500' : 'bg-red-500';

  const bg = darkMode ? 'bg-gray-900' : 'bg-slate-100';
  const cardBg = darkMode ? 'bg-gray-800' : 'bg-white';
  const text = darkMode ? 'text-white' : 'text-gray-900';
  const subtext = darkMode ? 'text-gray-400' : 'text-gray-500';

  return (
    <div className={`min-h-screen ${bg} flex flex-col`}>
      {/* Timer bar + header */}
      <div className={`${cardBg} shadow-md px-6 py-4`}>
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between mb-3">
            <span className={`text-sm font-semibold ${subtext}`}>
              {questionIndex + 1} / {totalQuestions}. kérdés
            </span>
            <span
              className={`text-2xl font-extrabold tabular-nums transition-colors ${
                timeLeft <= 8 ? 'text-red-500' : timeLeft <= 15 ? 'text-amber-500' : 'text-emerald-500'
              }`}
            >
              {timeLeft}s
            </span>
          </div>
          {/* Timer bar */}
          <div className="w-full h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-1000 ease-linear ${timerColor}`}
              style={{ width: `${timerPct}%` }}
            />
          </div>
        </div>
      </div>

      {/* Question */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-8">
        <div className="w-full max-w-3xl mx-auto">
          <div className={`${cardBg} rounded-3xl shadow-lg px-8 py-8 mb-8 text-center`}>
            <p className={`text-2xl md:text-3xl font-bold leading-snug ${text}`}>
              {question.question}
            </p>
          </div>

          {/* Answers grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {question.answers.map((ans, i) => {
              const style = ANSWER_STYLES[i];
              const isSelected = selected === i;
              return (
                <button
                  key={i}
                  onClick={() => submit(i)}
                  disabled={locked}
                  className={`
                    relative flex items-center gap-4 p-5 rounded-2xl border-b-4 text-white font-bold text-lg
                    transition-all duration-200 active:scale-95 disabled:cursor-default
                    ${style.bg} ${isSelected ? style.selected + ' scale-[1.02]' : ''}
                    ${locked && !isSelected ? 'opacity-60' : ''}
                    shadow-lg
                  `}
                >
                  <span
                    className={`shrink-0 w-9 h-9 rounded-xl flex items-center justify-center font-extrabold text-base ${style.label}`}
                  >
                    {ANSWER_LABELS[i]}
                  </span>
                  <span className="text-left leading-tight">{ans}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom progress bar */}
      <div className={`${cardBg} px-6 py-4 shadow-inner`}>
        <div className="max-w-3xl mx-auto">
          <div className="flex justify-between text-xs font-medium mb-1.5">
            <span className={subtext}>Haladás</span>
            <span className={subtext}>{questionIndex + 1} / {totalQuestions}</span>
          </div>
          <div className="w-full h-2.5 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500 rounded-full transition-all duration-500"
              style={{ width: `${((questionIndex) / totalQuestions) * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
