import { Monitor, Play, Clock, HelpCircle } from 'lucide-react';
import { QuizAttempt } from '../lib/supabase';

interface Props {
  darkMode: boolean;
  attempts: QuizAttempt[];
  onStart: () => void;
}

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString('hu-HU', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function getScoreColor(pct: number) {
  if (pct >= 80) return 'text-emerald-500';
  if (pct >= 50) return 'text-yellow-500';
  return 'text-red-500';
}

export default function StartScreen({ darkMode, attempts, onStart }: Props) {
  const card = darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200';
  const text = darkMode ? 'text-white' : 'text-gray-900';
  const subtext = darkMode ? 'text-gray-400' : 'text-gray-500';
  const border = darkMode ? 'border-gray-700' : 'border-gray-200';

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      <div className="w-full max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-blue-500 shadow-lg shadow-blue-500/30 mb-5">
            <Monitor size={38} className="text-white" />
          </div>
          <h1 className={`text-4xl font-extrabold mb-2 ${text}`}>
            Számítógép Kvíz
          </h1>
          <p className={`text-lg ${subtext}`}>
            Teszteld a tudásodat a számítógép hardvereiről és perifériáiról!
          </p>
        </div>

        {/* Info cards */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className={`${card} border rounded-2xl p-4 flex items-center gap-3`}>
            <HelpCircle className="text-blue-500 shrink-0" size={24} />
            <div>
              <p className={`font-bold ${text}`}>17 kérdés</p>
              <p className={`text-sm ${subtext}`}>Hardver és perifériák</p>
            </div>
          </div>
          <div className={`${card} border rounded-2xl p-4 flex items-center gap-3`}>
            <Clock className="text-orange-500 shrink-0" size={24} />
            <div>
              <p className={`font-bold ${text}`}>30 mp / kérdés</p>
              <p className={`text-sm ${subtext}`}>Gondolkodj gyorsan!</p>
            </div>
          </div>
        </div>

        {/* Start button */}
        <button
          onClick={onStart}
          className="w-full flex items-center justify-center gap-3 bg-blue-500 hover:bg-blue-400 active:bg-blue-600 text-white font-extrabold text-xl py-5 rounded-2xl shadow-lg shadow-blue-500/30 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] mb-8"
        >
          <Play size={24} fill="white" />
          Játék indítása!
        </button>

        {/* History */}
        {attempts.length > 0 && (
          <div className={`${card} border rounded-2xl overflow-hidden`}>
            <div className={`px-5 py-4 border-b ${border}`}>
              <h2 className={`font-bold text-lg ${text}`}>Korábbi próbálkozások</h2>
            </div>
            <div className="divide-y divide-gray-200 dark:divide-gray-700 max-h-72 overflow-y-auto">
              {attempts.map((a) => (
                <div
                  key={a.id}
                  className={`flex items-center justify-between px-5 py-3 border-b ${border} last:border-0`}
                >
                  <div>
                    <p className={`text-sm font-medium ${text}`}>{formatDate(a.created_at)}</p>
                    <p className={`text-xs ${subtext}`}>
                      {a.score} / {a.total_questions} helyes válasz
                    </p>
                  </div>
                  <span className={`text-2xl font-extrabold ${getScoreColor(a.percentage)}`}>
                    {a.percentage}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
