import { CheckCircle, XCircle, Clock } from 'lucide-react';
import { Question } from '../data/questions';

const ANSWER_LABELS = ['A', 'B', 'C', 'D'];
const ANSWER_BG = ['bg-red-500', 'bg-blue-500', 'bg-amber-500', 'bg-emerald-500'];

interface Props {
  question: Question;
  selected: number | null;
  questionIndex: number;
  totalQuestions: number;
  darkMode: boolean;
  onNext: () => void;
}

export default function FeedbackScreen({
  question,
  selected,
  questionIndex,
  totalQuestions,
  darkMode,
  onNext,
}: Props) {
  const isCorrect = selected === question.correctIndex;
  const isTimeout = selected === null;

  const bg = darkMode ? 'bg-gray-900' : 'bg-slate-100';
  const cardBg = darkMode ? 'bg-gray-800' : 'bg-white';
  const text = darkMode ? 'text-white' : 'text-gray-900';
  const subtext = darkMode ? 'text-gray-400' : 'text-gray-500';

  return (
    <div className={`min-h-screen ${bg} flex flex-col`}>
      {/* Feedback banner */}
      <div
        className={`py-6 px-6 flex items-center justify-center gap-4 shadow-lg ${
          isTimeout
            ? 'bg-gray-600'
            : isCorrect
            ? 'bg-emerald-500'
            : 'bg-red-500'
        }`}
      >
        {isTimeout ? (
          <Clock size={32} className="text-white" />
        ) : isCorrect ? (
          <CheckCircle size={32} className="text-white" />
        ) : (
          <XCircle size={32} className="text-white" />
        )}
        <span className="text-white text-2xl font-extrabold">
          {isTimeout ? 'Lejárt az idő!' : isCorrect ? 'Helyes válasz!' : 'Helytelen válasz!'}
        </span>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-4 py-8">
        <div className="w-full max-w-3xl mx-auto">
          {/* Question recap */}
          <div className={`${cardBg} rounded-3xl shadow-lg px-8 py-6 mb-6 text-center`}>
            <p className={`text-xl font-semibold ${text}`}>{question.question}</p>
          </div>

          {/* Answers recap */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
            {question.answers.map((ans, i) => {
              const isCorrectAns = i === question.correctIndex;
              const isSelectedAns = i === selected;
              let classes = `flex items-center gap-3 p-4 rounded-2xl font-semibold text-base transition-all`;

              if (isCorrectAns) {
                classes += ' bg-emerald-500 text-white ring-4 ring-emerald-300 shadow-lg';
              } else if (isSelectedAns && !isCorrect) {
                classes += ' bg-red-500 text-white ring-4 ring-red-300 shadow-lg';
              } else {
                classes += ` ${ANSWER_BG[i]} text-white opacity-40`;
              }

              return (
                <div key={i} className={classes}>
                  <span className="shrink-0 w-8 h-8 rounded-lg bg-black/20 flex items-center justify-center font-bold">
                    {ANSWER_LABELS[i]}
                  </span>
                  <span className="leading-tight">{ans}</span>
                  {isCorrectAns && (
                    <CheckCircle size={18} className="ml-auto shrink-0" />
                  )}
                  {isSelectedAns && !isCorrect && (
                    <XCircle size={18} className="ml-auto shrink-0" />
                  )}
                </div>
              );
            })}
          </div>

          {!isCorrect && (
            <p className={`text-center mb-6 font-medium ${subtext}`}>
              A helyes válasz:{' '}
              <span className="font-bold text-emerald-500">
                {ANSWER_LABELS[question.correctIndex]}) {question.answers[question.correctIndex]}
              </span>
            </p>
          )}

          <button
            onClick={onNext}
            className="w-full bg-blue-500 hover:bg-blue-400 active:bg-blue-600 text-white font-extrabold text-lg py-4 rounded-2xl shadow-lg shadow-blue-500/30 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
          >
            {questionIndex + 1 < totalQuestions ? 'Következő kérdés →' : 'Eredmények megtekintése'}
          </button>
        </div>
      </div>

      {/* Bottom progress bar */}
      <div className={`${cardBg} px-6 py-4 shadow-inner`}>
        <div className="max-w-3xl mx-auto">
          <div className="flex justify-between text-xs font-medium mb-1.5">
            <span className={subtext}>Haladás</span>
            <span className={subtext}>{questionIndex + 1} / {totalQuestions}</span>
          </div>
          <div className="w-full h-2.5 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500 rounded-full transition-all duration-500"
              style={{ width: `${((questionIndex + 1) / totalQuestions) * 100}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
