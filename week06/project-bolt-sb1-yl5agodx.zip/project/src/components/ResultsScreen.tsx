import { Trophy, RotateCcw, Star } from 'lucide-react';
import { QuizAttempt } from '../lib/supabase';

interface Props {
  score: number;
  totalQuestions: number;
  attempts: QuizAttempt[];
  darkMode: boolean;
  onRestart: () => void;
}

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString('hu-HU', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function getScoreColor(pct: number) {
  if (pct >= 80) return 'text-emerald-500';
  if (pct >= 50) return 'text-amber-500';
  return 'text-red-500';
}

function getScoreBg(pct: number) {
  if (pct >= 80) return 'bg-emerald-500';
  if (pct >= 50) return 'bg-amber-500';
  return 'bg-red-500';
}

function getMessage(pct: number) {
  if (pct === 100) return 'Tökéletes eredmény! Zseniális vagy!';
  if (pct >= 80) return 'Kiváló munka! Nagyon jól sikerült!';
  if (pct >= 60) return 'Szép eredmény! Jó teljesítmény!';
  if (pct >= 40) return 'Tanulj még egy kicsit és sikerülni fog!';
  return 'Ne add fel, próbáld újra!';
}

export default function ResultsScreen({ score, totalQuestions, attempts, darkMode, onRestart }: Props) {
  const pct = Math.round((score / totalQuestions) * 100);

  const bg = darkMode ? 'bg-gray-900' : 'bg-slate-100';
  const cardBg = darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200';
  const text = darkMode ? 'text-white' : 'text-gray-900';
  const subtext = darkMode ? 'text-gray-400' : 'text-gray-500';
  const border = darkMode ? 'border-gray-700' : 'border-gray-200';

  return (
    <div className={`min-h-screen ${bg} flex flex-col items-center justify-center px-4 py-12`}>
      <div className="w-full max-w-2xl mx-auto">
        {/* Score card */}
        <div className={`${cardBg} border rounded-3xl shadow-xl overflow-hidden mb-6`}>
          {/* Top banner */}
          <div className={`${getScoreBg(pct)} py-8 px-6 text-center`}>
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white/20 mb-4">
              {pct >= 80 ? (
                <Trophy size={40} className="text-white" />
              ) : (
                <Star size={40} className="text-white" />
              )}
            </div>
            <p className="text-white text-5xl font-extrabold mb-1">{pct}%</p>
            <p className="text-white/90 text-lg font-medium">{getMessage(pct)}</p>
          </div>

          {/* Score details */}
          <div className="px-8 py-6 text-center">
            <p className={`text-3xl font-extrabold mb-1 ${text}`}>
              {score} / {totalQuestions}
            </p>
            <p className={`text-base ${subtext}`}>helyes válasz</p>
          </div>
        </div>

        {/* Restart button */}
        <button
          onClick={onRestart}
          className="w-full flex items-center justify-center gap-3 bg-blue-500 hover:bg-blue-400 active:bg-blue-600 text-white font-extrabold text-xl py-5 rounded-2xl shadow-lg shadow-blue-500/30 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] mb-8"
        >
          <RotateCcw size={22} />
          Újra kezdem!
        </button>

        {/* History */}
        {attempts.length > 0 && (
          <div className={`${cardBg} border rounded-2xl overflow-hidden`}>
            <div className={`px-5 py-4 border-b ${border}`}>
              <h2 className={`font-bold text-lg ${text}`}>Korábbi próbálkozások</h2>
            </div>
            <div className={`divide-y max-h-72 overflow-y-auto ${darkMode ? 'divide-gray-700' : 'divide-gray-200'}`}>
              {attempts.map((a, idx) => (
                <div
                  key={a.id}
                  className={`flex items-center justify-between px-5 py-3 ${idx === 0 ? (darkMode ? 'bg-blue-900/30' : 'bg-blue-50') : ''}`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <p className={`text-sm font-medium ${text}`}>{formatDate(a.created_at)}</p>
                      {idx === 0 && (
                        <span className="text-xs bg-blue-500 text-white px-2 py-0.5 rounded-full font-semibold">
                          Legutóbbi
                        </span>
                      )}
                    </div>
                    <p className={`text-xs ${subtext}`}>
                      {a.score} / {a.total_questions} helyes válasz
                    </p>
                  </div>
                  <span className={`text-2xl font-extrabold ${getScoreColor(a.percentage)}`}>
                    {a.percentage}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
