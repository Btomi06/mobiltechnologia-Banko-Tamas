export interface Question {
  question: string;
  answers: string[];
  correctIndex: number;
}

export const questions: Question[] = [
  {
    question: 'Melyik eszköz segítségével tudunk szöveget begépelni a számítógépbe?',
    answers: ['Egér', 'Monitor', 'Billentyűzet', 'Nyomtató'],
    correctIndex: 2,
  },
  {
    question: 'Melyik alkatrészt nevezzük a számítógép \u201Eagyának\u201D?',
    answers: ['Processzor (CPU)', 'Merevlemez (HDD)', 'Tápegység', 'Ház ventilátor'],
    correctIndex: 0,
  },
  {
    question: 'Melyik eszköz felelős azért, hogy lássuk a képeket és a videókat?',
    answers: ['Szkenner', 'Hangkártya', 'Monitor', 'Egérpad'],
    correctIndex: 2,
  },
  {
    question: 'Mi a feladata a Videókártyának (GPU)?',
    answers: [
      'A fájlok végleges mentése',
      'Az áram elosztása az alkatrészek között',
      'Grafikus számítások és a kép megjelenítése',
      'A számítógép bekapcsolása',
    ],
    correctIndex: 2,
  },
  {
    question: 'Melyik eszköz tartozik a beviteli perifériák közé?',
    answers: ['Hangszóró', 'Egér', 'Nyomtató', 'Monitor'],
    correctIndex: 1,
  },
  {
    question: 'Hová csatlakoznak a számítógép belső alkatrészei (például a processzor)?',
    answers: [
      'A gépház oldalához',
      'Közvetlenül a konnektorba',
      'Az Alaplaphoz',
      'A monitor hátuljához',
    ],
    correctIndex: 2,
  },
  {
    question: 'Mire való a RAM (operatív memória)?',
    answers: [
      'Itt tároljuk a fényképeinket örökre',
      'A futó programok adatainak ideiglenes tárolására',
      'Ez hűti le a számítógépet',
      'Ez méri az internet sebességét',
    ],
    correctIndex: 1,
  },
  {
    question: 'Melyik eszköz kimeneti periféria?',
    answers: ['Mikrofon', 'Billentyűzet', 'Hangszóró', 'Webkamera'],
    correctIndex: 2,
  },
  {
    question: 'Miben jobb egy SSD, mint egy hagyományos merevlemez (HDD)?',
    answers: [
      'Sokkal hangosabb',
      'Sokkal gyorsabb az adatok elérése',
      'Csak fekete színben létezik',
      'Nem lehet rá játékokat telepíteni',
    ],
    correctIndex: 1,
  },
  {
    question: 'Melyik állítás igaz az egérre?',
    answers: [
      'Csak nagybetűket lehet vele írni',
      'A képernyőn látható kurzort irányítjuk vele',
      'Ez az alkatrész végzi a matematikai számításokat',
      'A számítógép belsejében található, nem látható kívülről',
    ],
    correctIndex: 1,
  },
  {
    question: 'Melyik alkatrész biztosítja az áramot a többi egységnek?',
    answers: [
      'Tápegység',
      'Akkumulátor töltő (asztali gépnél)',
      'Alaplap',
      'Hangkártya',
    ],
    correctIndex: 0,
  },
  {
    question: 'Mire használjuk a Szkennert (lapolvasót)?',
    answers: [
      'Videójátékok irányítására',
      'Papír alapú dokumentumok digitális beolvasására',
      'Zenehallgatásra',
      'A monitor tisztítására',
    ],
    correctIndex: 1,
  },
  {
    question: 'Melyik belső alkatrész felelős a processzor hűtéséért?',
    answers: [
      'Hűtőborda és ventilátor',
      'DVD-meghajtó',
      'Webkamera',
      'Gépház lábai',
    ],
    correctIndex: 0,
  },
  {
    question: 'Mi kell ahhoz, hogy a tanár lásson téged egy online órán?',
    answers: ['Nyomtató', 'Egér', 'Webkamera', 'Pendrive'],
    correctIndex: 2,
  },
  {
    question: 'Mit jelent az SSD rövidítés?',
    answers: [
      'Super Speed Disk',
      'Solid State Drive',
      'System Storage Device',
      'Simple Screen Display',
    ],
    correctIndex: 1,
  },
  {
    question: 'Milyen típusú periféria a fejhallgató?',
    answers: ['Beviteli', 'Kimeneti', 'Tároló', 'Feldolgozó'],
    correctIndex: 1,
  },
  {
    question: 'Melyik eszköz tárolja el a fájljainkat akkor is, ha kikapcsoljuk a gépet?',
    answers: ['Processzor', 'RAM', 'Merevlemez vagy SSD', 'Alaplap'],
    correctIndex: 2,
  },
];
