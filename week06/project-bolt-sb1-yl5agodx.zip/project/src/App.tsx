import { useState, useEffect, useCallback } from 'react';
import { supabase, QuizAttempt } from './lib/supabase';
import { questions } from './data/questions';
import DarkModeToggle from './components/DarkModeToggle';
import StartScreen from './components/StartScreen';
import QuizQuestion from './components/QuizQuestion';
import FeedbackScreen from './components/FeedbackScreen';
import ResultsScreen from './components/ResultsScreen';

type Phase = 'start' | 'question' | 'feedback' | 'results';

export default function App() {
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('quiz-dark-mode');
    return saved ? saved === 'true' : window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  const [phase, setPhase] = useState<Phase>('start');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);

  const fetchAttempts = useCallback(async () => {
    const { data } = await supabase
      .from('quiz_attempts')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(20);
    if (data) setAttempts(data as QuizAttempt[]);
  }, []);

  useEffect(() => {
    fetchAttempts();
  }, [fetchAttempts]);

  useEffect(() => {
    localStorage.setItem('quiz-dark-mode', String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleStart = () => {
    setCurrentIndex(0);
    setScore(0);
    setSelectedAnswer(null);
    setPhase('question');
  };

  const handleAnswer = (answerIndex: number | null) => {
    const correct = answerIndex === questions[currentIndex].correctIndex;
    if (correct) setScore((s) => s + 1);
    setSelectedAnswer(answerIndex);
    setPhase('feedback');
  };

  const handleNext = async () => {
    const nextIndex = currentIndex + 1;
    if (nextIndex >= questions.length) {
      const pct = Math.round((score / questions.length) * 100);
      await supabase.from('quiz_attempts').insert({
        score,
        total_questions: questions.length,
        percentage: pct,
      });
      await fetchAttempts();
      setPhase('results');
    } else {
      setCurrentIndex(nextIndex);
      setSelectedAnswer(null);
      setPhase('question');
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setScore(0);
    setSelectedAnswer(null);
    setPhase('start');
  };

  const bg = darkMode ? 'bg-gray-900' : 'bg-slate-100';

  return (
    <div className={`min-h-screen ${bg} transition-colors duration-300`}>
      <DarkModeToggle darkMode={darkMode} onToggle={() => setDarkMode((d) => !d)} />

      {phase === 'start' && (
        <StartScreen darkMode={darkMode} attempts={attempts} onStart={handleStart} />
      )}

      {phase === 'question' && (
        <QuizQuestion
          key={currentIndex}
          question={questions[currentIndex]}
          questionIndex={currentIndex}
          totalQuestions={questions.length}
          darkMode={darkMode}
          onAnswer={handleAnswer}
        />
      )}

      {phase === 'feedback' && (
        <FeedbackScreen
          question={questions[currentIndex]}
          selected={selectedAnswer}
          questionIndex={currentIndex}
          totalQuestions={questions.length}
          darkMode={darkMode}
          onNext={handleNext}
        />
      )}

      {phase === 'results' && (
        <ResultsScreen
          score={score}
          totalQuestions={questions.length}
          attempts={attempts}
          darkMode={darkMode}
          onRestart={handleRestart}
        />
      )}
    </div>
  );
}
