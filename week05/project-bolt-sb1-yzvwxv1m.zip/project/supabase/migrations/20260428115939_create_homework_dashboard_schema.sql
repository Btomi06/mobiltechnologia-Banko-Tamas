
/*
  # Homework Dashboard Schema

  1. New Tables
    - `classes` - School classes (e.g. "5A", "6B")
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `created_at` (timestamptz)

    - `students` - Individual students
      - `id` (uuid, primary key)
      - `name` (text)
      - `class_id` (uuid, foreign key -> classes)
      - `created_at` (timestamptz)

    - `assignments` - Homework assignments
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `class_id` (uuid, foreign key -> classes, assignment given to whole class)
      - `due_date` (date, optional)
      - `max_score` (integer, optional, for point-based tracking)
      - `created_at` (timestamptz)

    - `completions` - Tracks which student completed which assignment
      - `id` (uuid, primary key)
      - `student_id` (uuid, foreign key -> students)
      - `assignment_id` (uuid, foreign key -> assignments)
      - `completed` (boolean)
      - `score` (integer, optional)
      - `created_at` (timestamptz)
      - UNIQUE constraint on (student_id, assignment_id)

  2. Security
    - RLS enabled on all tables
    - Policies allow all authenticated users full access (teacher dashboard)
*/

CREATE TABLE IF NOT EXISTS classes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  class_id uuid NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text DEFAULT '',
  class_id uuid NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  due_date date,
  max_score integer,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS completions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  assignment_id uuid NOT NULL REFERENCES assignments(id) ON DELETE CASCADE,
  completed boolean DEFAULT false,
  score integer,
  created_at timestamptz DEFAULT now(),
  UNIQUE(student_id, assignment_id)
);

CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_id);
CREATE INDEX IF NOT EXISTS idx_assignments_class ON assignments(class_id);
CREATE INDEX IF NOT EXISTS idx_completions_student ON completions(student_id);
CREATE INDEX IF NOT EXISTS idx_completions_assignment ON completions(assignment_id);

ALTER TABLE classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE completions ENABLE ROW LEVEL SECURITY;

-- Allow anon access for teacher dashboard (no auth requirement)
CREATE POLICY "Allow all select on classes"
  ON classes FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Allow all insert on classes"
  ON classes FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Allow all update on classes"
  ON classes FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all delete on classes"
  ON classes FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "Allow all select on students"
  ON students FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Allow all insert on students"
  ON students FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Allow all update on students"
  ON students FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all delete on students"
  ON students FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "Allow all select on assignments"
  ON assignments FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Allow all insert on assignments"
  ON assignments FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Allow all update on assignments"
  ON assignments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all delete on assignments"
  ON assignments FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "Allow all select on completions"
  ON completions FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Allow all insert on completions"
  ON completions FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Allow all update on completions"
  ON completions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Allow all delete on completions"
  ON completions FOR DELETE TO anon, authenticated USING (true);
