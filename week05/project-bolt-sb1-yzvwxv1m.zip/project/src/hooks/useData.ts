import { useState, useEffect, useCallback } from 'react';
import { supabase, Class, Student, Assignment, Completion } from '../lib/supabase';

export function useClasses() {
  const [classes, setClasses] = useState<Class[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('classes').select('*').order('name');
    setClasses(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);
  return { classes, loading, refresh: fetch };
}

export function useStudents() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('students')
      .select('*, classes(id, name, created_at)')
      .order('name');
    setStudents((data as Student[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);
  return { students, loading, refresh: fetch };
}

export function useAssignments() {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('assignments')
      .select('*, classes(id, name, created_at)')
      .order('created_at', { ascending: false });
    setAssignments((data as Assignment[]) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);
  return { assignments, loading, refresh: fetch };
}

export function useCompletions() {
  const [completions, setCompletions] = useState<Completion[]>([]);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('completions').select('*');
    setCompletions(data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { fetch(); }, [fetch]);
  return { completions, loading, refresh: fetch };
}

export async function toggleCompletion(
  studentId: string,
  assignmentId: string,
  current: boolean
) {
  await supabase
    .from('completions')
    .upsert(
      { student_id: studentId, assignment_id: assignmentId, completed: !current },
      { onConflict: 'student_id,assignment_id' }
    );
}

export async function updateScore(
  studentId: string,
  assignmentId: string,
  score: number | null
) {
  await supabase
    .from('completions')
    .upsert(
      { student_id: studentId, assignment_id: assignmentId, score },
      { onConflict: 'student_id,assignment_id' }
    );
}
