import { useMemo, useState } from 'react';
import { Search, Check, X, ChevronDown, ChevronUp, BookOpen, Calendar } from 'lucide-react';
import { Student, Assignment, Completion, Class } from '../lib/supabase';
import { toggleCompletion, updateScore } from '../hooks/useData';

type Props = {
  students: Student[];
  assignments: Assignment[];
  completions: Completion[];
  classes: Class[];
  onRefresh: () => void;
};

export default function AssignmentsView({ students, assignments, completions, classes, onRefresh }: Props) {
  const [search, setSearch] = useState('');
  const [filterClass, setFilterClass] = useState('');
  const [expandedAssignment, setExpandedAssignment] = useState<string | null>(null);
  const [editingScore, setEditingScore] = useState<{ studentId: string; assignmentId: string } | null>(null);
  const [scoreInput, setScoreInput] = useState('');

  const completionMap = useMemo(() => {
    const map = new Map<string, Completion>();
    for (const c of completions) {
      map.set(`${c.student_id}:${c.assignment_id}`, c);
    }
    return map;
  }, [completions]);

  const filtered = useMemo(() => {
    let list = assignments;
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(a =>
        a.title.toLowerCase().includes(q) ||
        (a.classes?.name ?? '').toLowerCase().includes(q)
      );
    }
    if (filterClass) list = list.filter(a => a.class_id === filterClass);
    return list;
  }, [assignments, search, filterClass]);

  const getAssignmentStats = (assignmentId: string, classId: string) => {
    const classStudents = students.filter(s => s.class_id === classId);
    const total = classStudents.length;
    const done = classStudents.filter(s => completionMap.get(`${s.id}:${assignmentId}`)?.completed === true).length;
    return { total, done, rate: total > 0 ? Math.round((done / total) * 100) : 0 };
  };

  const handleToggle = async (studentId: string, assignmentId: string) => {
    const current = completionMap.get(`${studentId}:${assignmentId}`)?.completed ?? false;
    await toggleCompletion(studentId, assignmentId, current);
    onRefresh();
  };

  const handleScoreSubmit = async (studentId: string, assignmentId: string) => {
    const score = scoreInput === '' ? null : parseInt(scoreInput);
    await updateScore(studentId, assignmentId, score);
    setEditingScore(null);
    setScoreInput('');
    onRefresh();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-52">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Keresés feladat, osztály szerint..."
            className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <select
          value={filterClass}
          onChange={e => setFilterClass(e.target.value)}
          className="border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
        >
          <option value="">Minden osztály</option>
          {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm flex flex-col items-center justify-center py-16 text-gray-400">
            <BookOpen className="w-10 h-10 mb-3 opacity-40" />
            <p className="text-sm">Nincs találat</p>
          </div>
        ) : filtered.map(assignment => {
          const stats = getAssignmentStats(assignment.id, assignment.class_id);
          const isExpanded = expandedAssignment === assignment.id;
          const classStudents = students.filter(s => s.class_id === assignment.class_id).sort((a, b) => a.name.localeCompare(b.name));

          return (
            <div key={assignment.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <button
                onClick={() => setExpandedAssignment(isExpanded ? null : assignment.id)}
                className="w-full flex items-center gap-4 px-6 py-4 hover:bg-gray-50/50 transition-colors text-left"
              >
                <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <BookOpen className="w-5 h-5 text-amber-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-gray-900">{assignment.title}</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                      {assignment.classes?.name}
                    </span>
                    {assignment.due_date && (
                      <span className="inline-flex items-center gap-1 text-xs text-gray-400">
                        <Calendar className="w-3 h-3" />
                        {new Date(assignment.due_date).toLocaleDateString('hu-HU')}
                      </span>
                    )}
                  </div>
                  {assignment.description && (
                    <p className="text-xs text-gray-400 mt-0.5 truncate">{assignment.description}</p>
                  )}
                </div>
                <div className="flex items-center gap-4 flex-shrink-0">
                  <div className="text-right">
                    <div className="text-sm font-semibold text-gray-900">{stats.rate}%</div>
                    <div className="text-xs text-gray-400">{stats.done}/{stats.total} kész</div>
                  </div>
                  <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500 rounded-full transition-all"
                      style={{ width: `${stats.rate}%` }}
                    />
                  </div>
                  {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                </div>
              </button>

              {isExpanded && (
                <div className="border-t border-gray-100">
                  {classStudents.length === 0 ? (
                    <div className="px-6 py-8 text-center text-sm text-gray-400">Nincsenek diákok ebben az osztályban.</div>
                  ) : (
                    <div className="divide-y divide-gray-50">
                      {classStudents.map(student => {
                        const c = completionMap.get(`${student.id}:${assignment.id}`);
                        const done = c?.completed === true;
                        const isEditingThisScore = editingScore?.studentId === student.id && editingScore?.assignmentId === assignment.id;

                        return (
                          <div key={student.id} className="flex items-center gap-4 px-6 py-3">
                            <button
                              onClick={() => handleToggle(student.id, assignment.id)}
                              className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center transition-all flex-shrink-0 ${
                                done
                                  ? 'bg-green-500 border-green-500 text-white hover:bg-green-600 hover:border-green-600'
                                  : 'border-gray-300 hover:border-gray-400 bg-white'
                              }`}
                            >
                              {done && <Check className="w-4 h-4" />}
                            </button>
                            <span className={`flex-1 text-sm ${done ? 'text-gray-900 font-medium' : 'text-gray-500'}`}>
                              {student.name}
                            </span>
                            {assignment.max_score != null && (
                              <div className="flex items-center gap-2">
                                {isEditingThisScore ? (
                                  <div className="flex items-center gap-1">
                                    <input
                                      type="number"
                                      value={scoreInput}
                                      onChange={e => setScoreInput(e.target.value)}
                                      placeholder={`/${assignment.max_score}`}
                                      autoFocus
                                      onKeyDown={e => {
                                        if (e.key === 'Enter') handleScoreSubmit(student.id, assignment.id);
                                        if (e.key === 'Escape') { setEditingScore(null); setScoreInput(''); }
                                      }}
                                      className="w-20 border border-gray-200 rounded-lg px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                    <button
                                      onClick={() => handleScoreSubmit(student.id, assignment.id)}
                                      className="p-1 text-green-600 hover:bg-green-50 rounded"
                                    ><Check className="w-4 h-4" /></button>
                                    <button
                                      onClick={() => { setEditingScore(null); setScoreInput(''); }}
                                      className="p-1 text-gray-400 hover:bg-gray-50 rounded"
                                    ><X className="w-4 h-4" /></button>
                                  </div>
                                ) : (
                                  <button
                                    onClick={() => {
                                      setEditingScore({ studentId: student.id, assignmentId: assignment.id });
                                      setScoreInput(c?.score?.toString() ?? '');
                                    }}
                                    className="text-sm text-gray-400 hover:text-gray-600 border border-dashed border-gray-200 hover:border-gray-400 rounded-lg px-3 py-1 transition-colors"
                                  >
                                    {c?.score != null ? `${c.score}/${assignment.max_score}` : `—/${assignment.max_score}`}
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
      <p className="text-xs text-gray-400 text-right">{filtered.length} feladat megjelenítve</p>
    </div>
  );
}
