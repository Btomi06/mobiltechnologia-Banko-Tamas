import { useMemo, useState } from 'react';
import { BarChart3, TrendingUp, Users, BookOpen, Award } from 'lucide-react';
import { Student, Assignment, Completion, Class } from '../lib/supabase';

type Props = {
  students: Student[];
  assignments: Assignment[];
  completions: Completion[];
  classes: Class[];
};

function StatCard({ label, value, sub, color, icon: Icon }: {
  label: string;
  value: string | number;
  sub?: string;
  color: string;
  icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex items-start gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${color}`}>
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <div className="text-2xl font-bold text-gray-900">{value}</div>
        <div className="text-sm text-gray-500">{label}</div>
        {sub && <div className="text-xs text-gray-400 mt-0.5">{sub}</div>}
      </div>
    </div>
  );
}

export default function StatisticsView({ students, assignments, completions, classes }: Props) {
  const [filterClass, setFilterClass] = useState('');

  const completionMap = useMemo(() => {
    const map = new Map<string, Completion>();
    for (const c of completions) map.set(`${c.student_id}:${c.assignment_id}`, c);
    return map;
  }, [completions]);

  const filteredStudents = useMemo(() =>
    filterClass ? students.filter(s => s.class_id === filterClass) : students,
    [students, filterClass]
  );
  const filteredAssignments = useMemo(() =>
    filterClass ? assignments.filter(a => a.class_id === filterClass) : assignments,
    [assignments, filterClass]
  );

  const overallStats = useMemo(() => {
    let totalPairs = 0, donePairs = 0;
    const scores: number[] = [];
    for (const s of filteredStudents) {
      const sAssignments = filteredAssignments.filter(a => a.class_id === s.class_id);
      for (const a of sAssignments) {
        totalPairs++;
        const c = completionMap.get(`${s.id}:${a.id}`);
        if (c?.completed) donePairs++;
        if (c?.score != null) scores.push(c.score);
      }
    }
    const rate = totalPairs > 0 ? Math.round((donePairs / totalPairs) * 100) : 0;
    const avgScore = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;
    return { rate, avgScore, donePairs, totalPairs };
  }, [filteredStudents, filteredAssignments, completionMap]);

  const classStats = useMemo(() => {
    return classes.map(cls => {
      const clsStudents = students.filter(s => s.class_id === cls.id);
      const clsAssignments = assignments.filter(a => a.class_id === cls.id);
      let total = 0, done = 0;
      const scores: number[] = [];
      for (const s of clsStudents) {
        for (const a of clsAssignments) {
          total++;
          const c = completionMap.get(`${s.id}:${a.id}`);
          if (c?.completed) done++;
          if (c?.score != null) scores.push(c.score);
        }
      }
      const rate = total > 0 ? Math.round((done / total) * 100) : 0;
      const avgScore = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;
      return { ...cls, rate, done, total, avgScore, studentCount: clsStudents.length, assignmentCount: clsAssignments.length };
    }).sort((a, b) => b.rate - a.rate);
  }, [classes, students, assignments, completionMap]);

  const topStudents = useMemo(() => {
    return filteredStudents.map(s => {
      const sAssignments = filteredAssignments.filter(a => a.class_id === s.class_id);
      const total = sAssignments.length;
      const done = sAssignments.filter(a => completionMap.get(`${s.id}:${a.id}`)?.completed).length;
      const rate = total > 0 ? Math.round((done / total) * 100) : 0;
      const scores = sAssignments.map(a => completionMap.get(`${s.id}:${a.id}`)?.score).filter((sc): sc is number => sc != null);
      const avgScore = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;
      return { ...s, rate, done, total, avgScore };
    }).sort((a, b) => b.rate - a.rate).slice(0, 10);
  }, [filteredStudents, filteredAssignments, completionMap]);

  const getBarColor = (rate: number) => {
    if (rate >= 75) return 'bg-green-500';
    if (rate >= 40) return 'bg-yellow-400';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div />
        <select
          value={filterClass}
          onChange={e => setFilterClass(e.target.value)}
          className="border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
        >
          <option value="">Összes osztály</option>
          {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Átlagos teljesítés"
          value={`${overallStats.rate}%`}
          sub={`${overallStats.donePairs}/${overallStats.totalPairs} feladat kész`}
          color="bg-blue-100 text-blue-600"
          icon={TrendingUp}
        />
        <StatCard
          label="Átlag pontszám"
          value={overallStats.avgScore != null ? overallStats.avgScore : '—'}
          sub="pontozásos feladatoknál"
          color="bg-amber-100 text-amber-600"
          icon={Award}
        />
        <StatCard
          label="Diákok száma"
          value={filteredStudents.length}
          sub={filterClass ? classes.find(c => c.id === filterClass)?.name : `${classes.length} osztályban`}
          color="bg-emerald-100 text-emerald-600"
          icon={Users}
        />
        <StatCard
          label="Feladatok száma"
          value={filteredAssignments.length}
          sub={filterClass ? '' : `${classes.length} osztályhoz`}
          color="bg-rose-100 text-rose-600"
          icon={BookOpen}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex items-center gap-2 mb-5">
            <BarChart3 className="w-5 h-5 text-gray-400" />
            <h2 className="font-semibold text-gray-900">Osztályok teljesítése</h2>
          </div>
          <div className="space-y-4">
            {classStats.map(cls => (
              <div key={cls.id}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-800">{cls.name}</span>
                    <span className="text-xs text-gray-400">{cls.studentCount} diák, {cls.assignmentCount} feladat</span>
                  </div>
                  <div className="flex items-center gap-3">
                    {cls.avgScore != null && (
                      <span className="text-xs text-gray-400">avg: {cls.avgScore}pt</span>
                    )}
                    <span className={`text-sm font-semibold ${
                      cls.rate >= 75 ? 'text-green-700' : cls.rate >= 40 ? 'text-yellow-700' : 'text-red-600'
                    }`}>{cls.rate}%</span>
                  </div>
                </div>
                <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${getBarColor(cls.rate)}`}
                    style={{ width: `${cls.rate}%` }}
                  />
                </div>
              </div>
            ))}
            {classStats.length === 0 && (
              <p className="text-sm text-gray-400 text-center py-4">Nincs adat</p>
            )}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <div className="flex items-center gap-2 mb-5">
            <Award className="w-5 h-5 text-gray-400" />
            <h2 className="font-semibold text-gray-900">Top 10 diák (teljesítés alapján)</h2>
          </div>
          <div className="space-y-3">
            {topStudents.map((s, i) => (
              <div key={s.id} className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                  i === 0 ? 'bg-yellow-100 text-yellow-700' :
                  i === 1 ? 'bg-gray-100 text-gray-600' :
                  i === 2 ? 'bg-orange-100 text-orange-700' :
                  'bg-gray-50 text-gray-400'
                }`}>
                  {i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-gray-800 truncate">{s.name}</span>
                    <span className="text-xs text-gray-400 flex-shrink-0">{s.classes?.name}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${getBarColor(s.rate)}`} style={{ width: `${s.rate}%` }} />
                    </div>
                    <span className={`text-xs font-semibold flex-shrink-0 ${
                      s.rate >= 75 ? 'text-green-700' : s.rate >= 40 ? 'text-yellow-700' : 'text-red-600'
                    }`}>{s.rate}%</span>
                  </div>
                </div>
                {s.avgScore != null && (
                  <div className="text-xs text-gray-400 flex-shrink-0">{s.avgScore}pt</div>
                )}
              </div>
            ))}
            {topStudents.length === 0 && (
              <p className="text-sm text-gray-400 text-center py-4">Nincs adat</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
