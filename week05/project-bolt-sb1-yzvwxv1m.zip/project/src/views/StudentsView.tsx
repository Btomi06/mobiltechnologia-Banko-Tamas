import { useMemo, useState } from 'react';
import { Search, ChevronDown, ChevronUp, User } from 'lucide-react';
import { Student, Assignment, Completion, Class } from '../lib/supabase';

type Props = {
  students: Student[];
  assignments: Assignment[];
  completions: Completion[];
  classes: Class[];
};

function getProgressColor(rate: number) {
  if (rate >= 75) return 'bg-green-100 border-green-300';
  if (rate >= 40) return 'bg-yellow-100 border-yellow-300';
  return 'bg-red-100 border-red-300';
}

function getProgressBarColor(rate: number) {
  if (rate >= 75) return 'bg-green-500';
  if (rate >= 40) return 'bg-yellow-400';
  return 'bg-red-500';
}

function getProgressTextColor(rate: number) {
  if (rate >= 75) return 'text-green-700';
  if (rate >= 40) return 'text-yellow-700';
  return 'text-red-700';
}

export default function StudentsView({ students, assignments, completions, classes }: Props) {
  const [search, setSearch] = useState('');
  const [filterClass, setFilterClass] = useState('');
  const [filterAssignment, setFilterAssignment] = useState('');
  const [sortField, setSortField] = useState<'name' | 'rate' | 'class'>('name');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const completionMap = useMemo(() => {
    const map = new Map<string, Completion>();
    for (const c of completions) {
      map.set(`${c.student_id}:${c.assignment_id}`, c);
    }
    return map;
  }, [completions]);

  const studentData = useMemo(() => {
    return students.map(s => {
      const studentAssignments = assignments.filter(a => a.class_id === s.class_id);
      const total = studentAssignments.length;
      const done = studentAssignments.filter(a => {
        const c = completionMap.get(`${s.id}:${a.id}`);
        return c?.completed === true;
      }).length;
      const rate = total > 0 ? Math.round((done / total) * 100) : 0;
      const scores = studentAssignments
        .map(a => completionMap.get(`${s.id}:${a.id}`)?.score)
        .filter((sc): sc is number => sc != null);
      const avg = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;
      return { ...s, total, done, rate, avg };
    });
  }, [students, assignments, completionMap]);

  const filtered = useMemo(() => {
    let list = studentData;
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(s =>
        s.name.toLowerCase().includes(q) ||
        (s.classes?.name ?? '').toLowerCase().includes(q)
      );
    }
    if (filterClass) list = list.filter(s => s.class_id === filterClass);
    if (filterAssignment) {
      const a = assignments.find(a => a.id === filterAssignment);
      if (a) list = list.filter(s => s.class_id === a.class_id);
    }

    return [...list].sort((a, b) => {
      let cmp = 0;
      if (sortField === 'name') cmp = a.name.localeCompare(b.name);
      else if (sortField === 'rate') cmp = a.rate - b.rate;
      else if (sortField === 'class') cmp = (a.classes?.name ?? '').localeCompare(b.classes?.name ?? '');
      return sortDir === 'asc' ? cmp : -cmp;
    });
  }, [studentData, search, filterClass, filterAssignment, assignments, sortField, sortDir]);

  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('asc'); }
  };

  const SortIcon = ({ field }: { field: typeof sortField }) => {
    if (sortField !== field) return <ChevronDown className="w-3.5 h-3.5 opacity-30" />;
    return sortDir === 'asc' ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />;
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-52">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Keresés diák, osztály szerint..."
            className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <select
          value={filterClass}
          onChange={e => setFilterClass(e.target.value)}
          className="border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
        >
          <option value="">Minden osztály</option>
          {classes.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select
          value={filterAssignment}
          onChange={e => setFilterAssignment(e.target.value)}
          className="border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
        >
          <option value="">Minden feladat</option>
          {assignments.map(a => (
            <option key={a.id} value={a.id}>{a.title} ({a.classes?.name})</option>
          ))}
        </select>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="grid grid-cols-[2fr_1fr_1fr_1.5fr_80px] gap-4 px-6 py-3 bg-gray-50 border-b border-gray-100 text-xs font-semibold text-gray-500 uppercase tracking-wide">
          <button onClick={() => toggleSort('name')} className="flex items-center gap-1 hover:text-gray-700 transition-colors text-left">
            Diák <SortIcon field="name" />
          </button>
          <button onClick={() => toggleSort('class')} className="flex items-center gap-1 hover:text-gray-700 transition-colors">
            Osztály <SortIcon field="class" />
          </button>
          <button onClick={() => toggleSort('rate')} className="flex items-center gap-1 hover:text-gray-700 transition-colors">
            Haladás <SortIcon field="rate" />
          </button>
          <div>Haladási sáv</div>
          <div>Átl. pont</div>
        </div>

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-400">
            <User className="w-10 h-10 mb-3 opacity-40" />
            <p className="text-sm">Nincs találat</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {filtered.map(s => (
              <div
                key={s.id}
                className={`grid grid-cols-[2fr_1fr_1fr_1.5fr_80px] gap-4 px-6 py-4 items-center border-l-4 transition-colors hover:bg-gray-50/50 ${getProgressColor(s.rate)}`}
              >
                <div className="font-medium text-gray-900 text-sm">{s.name}</div>
                <div className="text-sm text-gray-500">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-white border border-gray-200 text-gray-700">
                    {s.classes?.name ?? '—'}
                  </span>
                </div>
                <div className={`text-sm font-semibold ${getProgressTextColor(s.rate)}`}>
                  {s.rate}%
                  <span className="ml-1 text-xs font-normal text-gray-400">({s.done}/{s.total})</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${getProgressBarColor(s.rate)}`}
                      style={{ width: `${s.rate}%` }}
                    />
                  </div>
                </div>
                <div className="text-sm text-gray-600 font-medium">
                  {s.avg != null ? s.avg : <span className="text-gray-300">—</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <p className="text-xs text-gray-400 text-right">{filtered.length} diák megjelenítve</p>
    </div>
  );
}
