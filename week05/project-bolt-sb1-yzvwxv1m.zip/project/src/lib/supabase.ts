import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Class = {
  id: string;
  name: string;
  created_at: string;
};

export type Student = {
  id: string;
  name: string;
  class_id: string;
  created_at: string;
  classes?: Class;
};

export type Assignment = {
  id: string;
  title: string;
  description: string;
  class_id: string;
  due_date: string | null;
  max_score: number | null;
  created_at: string;
  classes?: Class;
};

export type Completion = {
  id: string;
  student_id: string;
  assignment_id: string;
  completed: boolean;
  score: number | null;
  created_at: string;
};

export type StudentWithProgress = Student & {
  completions: Completion[];
  completion_rate: number;
  avg_score: number | null;
};
