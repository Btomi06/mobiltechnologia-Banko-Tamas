import { useState, useCallback } from 'react';
import { Users, BookOpen, BarChart3, Plus, Upload, GraduationCap, RefreshCw } from 'lucide-react';
import { useClasses, useStudents, useAssignments, useCompletions } from './hooks/useData';
import StudentsView from './views/StudentsView';
import AssignmentsView from './views/AssignmentsView';
import StatisticsView from './views/StatisticsView';
import BulkImportModal from './components/BulkImportModal';
import AddClassModal from './components/AddClassModal';
import AddAssignmentModal from './components/AddAssignmentModal';

type Tab = 'students' | 'assignments' | 'statistics';

export default function App() {
  const [tab, setTab] = useState<Tab>('students');
  const [modal, setModal] = useState<'bulk' | 'class' | 'assignment' | null>(null);

  const { classes, refresh: refreshClasses } = useClasses();
  const { students, refresh: refreshStudents } = useStudents();
  const { assignments, refresh: refreshAssignments } = useAssignments();
  const { completions, refresh: refreshCompletions } = useCompletions();

  const refreshAll = useCallback(() => {
    refreshClasses();
    refreshStudents();
    refreshAssignments();
    refreshCompletions();
  }, [refreshClasses, refreshStudents, refreshAssignments, refreshCompletions]);

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: 'students', label: 'Diákok', icon: Users },
    { id: 'assignments', label: 'Feladatok', icon: BookOpen },
    { id: 'statistics', label: 'Statisztika', icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-base font-bold text-gray-900 leading-tight">Házifeladat Dashboard</h1>
                <p className="text-xs text-gray-400 leading-tight">Diákok haladásának nyomon követése</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={refreshAll}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-400 hover:text-gray-600"
                title="Frissítés"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setModal('class')}
                className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-xl transition-colors border border-gray-200"
              >
                <Plus className="w-4 h-4" />
                Osztály
              </button>
              <button
                onClick={() => setModal('assignment')}
                className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-xl transition-colors border border-gray-200"
              >
                <Plus className="w-4 h-4" />
                Feladat
              </button>
              <button
                onClick={() => setModal('bulk')}
                className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span className="hidden sm:inline">Importálás</span>
              </button>
            </div>
          </div>

          <nav className="flex gap-1 pb-0 -mb-px">
            {tabs.map(t => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                    tab === t.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-200'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {t.label}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {tab === 'students' && (
          <StudentsView
            students={students}
            assignments={assignments}
            completions={completions}
            classes={classes}
          />
        )}
        {tab === 'assignments' && (
          <AssignmentsView
            students={students}
            assignments={assignments}
            completions={completions}
            classes={classes}
            onRefresh={refreshCompletions}
          />
        )}
        {tab === 'statistics' && (
          <StatisticsView
            students={students}
            assignments={assignments}
            completions={completions}
            classes={classes}
          />
        )}
      </main>

      {modal === 'bulk' && (
        <BulkImportModal onClose={() => setModal(null)} onDone={refreshAll} />
      )}
      {modal === 'class' && (
        <AddClassModal onClose={() => setModal(null)} onDone={refreshAll} />
      )}
      {modal === 'assignment' && (
        <AddAssignmentModal classes={classes} onClose={() => setModal(null)} onDone={refreshAll} />
      )}
    </div>
  );
}
