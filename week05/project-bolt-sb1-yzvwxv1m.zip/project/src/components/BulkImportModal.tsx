import { useState } from 'react';
import { X, Upload, AlertCircle, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

type Props = {
  onClose: () => void;
  onDone: () => void;
};

export default function BulkImportModal({ onClose, onDone }: Props) {
  const [text, setText] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const handleImport = async () => {
    const lines = text.trim().split('\n').filter(l => l.trim());
    if (!lines.length) return;

    setStatus('loading');
    try {
      let imported = 0;
      for (const line of lines) {
        const cols = line.split(';').map(c => c.trim()).filter(Boolean);
        if (cols.length < 2) continue;
        const [className, ...studentNames] = cols;

        const { data: existingClass } = await supabase
          .from('classes')
          .select('id')
          .eq('name', className)
          .maybeSingle();

        let classId: string;
        if (existingClass) {
          classId = existingClass.id;
        } else {
          const { data: newClass, error } = await supabase
            .from('classes')
            .insert({ name: className })
            .select('id')
            .single();
          if (error) throw error;
          classId = newClass.id;
        }

        for (const studentName of studentNames) {
          if (!studentName) continue;
          const { data: existing } = await supabase
            .from('students')
            .select('id')
            .eq('name', studentName)
            .eq('class_id', classId)
            .maybeSingle();
          if (!existing) {
            await supabase.from('students').insert({ name: studentName, class_id: classId });
            imported++;
          }
        }
      }
      setStatus('done');
      setMessage(`Sikeresen importálva: ${imported} diák.`);
      setTimeout(() => { onDone(); onClose(); }, 1500);
    } catch (e) {
      setStatus('error');
      setMessage('Hiba történt az importálás során.');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg">
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <Upload className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Tömeges importálás</h2>
              <p className="text-sm text-gray-500">Osztály és diákok beillesztése</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-gray-50 rounded-xl p-4 text-sm text-gray-600 space-y-1">
            <p className="font-medium text-gray-700">Formátum (pontosvesszővel elválasztva):</p>
            <p className="font-mono text-xs bg-white border border-gray-200 rounded px-3 py-2">
              osztály;diák1;diák2;diák3
            </p>
            <p className="text-xs text-gray-400 mt-1">Minden sor egy osztályt jelent. Több sor = több osztály.</p>
          </div>

          <textarea
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder={"5A;Kovács Péter;Nagy Anna;Szabó Béla\n6B;Tóth Gábor;Varga Eszter"}
            className="w-full h-48 font-mono text-sm border border-gray-200 rounded-xl p-3 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />

          {status === 'done' && (
            <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg px-4 py-3">
              <CheckCircle className="w-4 h-4" />
              <span className="text-sm">{message}</span>
            </div>
          )}
          {status === 'error' && (
            <div className="flex items-center gap-2 text-red-700 bg-red-50 rounded-lg px-4 py-3">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">{message}</span>
            </div>
          )}
        </div>

        <div className="flex gap-3 p-6 border-t border-gray-100">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Mégse
          </button>
          <button
            onClick={handleImport}
            disabled={!text.trim() || status === 'loading'}
            className="flex-1 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl text-sm font-medium transition-colors"
          >
            {status === 'loading' ? 'Importálás...' : 'Importálás'}
          </button>
        </div>
      </div>
    </div>
  );
}
